package DTO;

import java.io.Serializable;

public class RegionDTO implements Serializable {
	private String code; // varchar2(20)
	private String firstName; // varchar2(20)
	private String secondName; // varchar2(20)
	private String thirdName; // varchar2(20)
	private String X; // varchar2(5)
	private String Y; // varchar2(5)

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSecondName() {
		return this.secondName;
	}

	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}

	public String getThirdName() {
		return this.thirdName;
	}

	public void setThirdName(String thirdName) {
		this.thirdName = thirdName;
	}

	public String getX() {
		return this.X;
	}

	public void setX(String X) {
		this.X = X;
	}

	public String getY() {
		return this.Y;
	}

	public void setY(String Y) {
		this.Y = Y;
	}

}
