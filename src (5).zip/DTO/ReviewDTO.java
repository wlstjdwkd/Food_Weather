package DTO;

import java.io.Serializable;

public class ReviewDTO implements Serializable {

	private String reg_date;
	private String content; // varchar2(100)
	private int rating; // Number
	private String mem_id; // varchar2(5)

	private String res_id; // varchar2(5)
	private String rev_id; // varchar2(5)

	public ReviewDTO(String reg_date, String content, int rating, String mem_id) {
		this.reg_date = reg_date;
		this.content = content;
		this.rating = rating;
		this.mem_id = mem_id;
	}

	public ReviewDTO() {

	}

	public int getRating() {
		return this.rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRes_id() {
		return this.res_id;
	}

	public void setRes_id(String res_id) {
		this.res_id = res_id;
	}

	public String getMem_id() {
		return this.mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getRev_id() {
		return this.rev_id;
	}

	public void setRev_id(String rev_id) {
		this.rev_id = rev_id;
	}

	public String getReg_date() {
		return reg_date;
	}

	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}

}
