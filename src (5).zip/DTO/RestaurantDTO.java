package DTO;

import java.io.Serializable;

public class RestaurantDTO implements Serializable {
	private String res_id; // varchar2 (5)
	private String name; // varchar2(20)
	private String category; // varchar2(10)
	private Double averagerating; // number
	private String address;

	public String getRes_id() {
		return this.res_id;
	}

	public void setRes_id(String res_id) {
		this.res_id = res_id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Double getAveragerating() {
		return this.averagerating;
	}

	public void setAveragerating(Double inputData) {
		this.averagerating = inputData;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
