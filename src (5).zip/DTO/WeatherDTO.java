package DTO;

import java.io.Serializable;
import java.time.LocalDateTime;

public class WeatherDTO implements Serializable {
	private double temperature; // 기온
	private double windSpeed; // 풍속
	private double humidity; // 습도
	private double fall; // 강수량
	private double fineDust; // 미세먼지
	private double ultraFineDust; // 초미세먼지
	private int sky; // 하늘 상태
	private LocalDateTime time; // 관측 시간

	public WeatherDTO(double temper, double wind, double reh, double rain, double pm10, double pm25, int sky,
			LocalDateTime time) {
		super();
		this.temperature = temper;
		this.windSpeed = wind;
		this.humidity = reh;
		this.fall = rain;
		this.fineDust = pm10;
		this.ultraFineDust = pm25;
		this.sky = sky;
		this.time = time;
	}

	public double getTemperature() {
		return temperature;
	}

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	public double getWindSpeed() {
		return windSpeed;
	}

	public void setWindSpeed(double windSpeed) {
		this.windSpeed = windSpeed;
	}

	public double getHumidity() {
		return humidity;
	}

	public void setHumidity(double humidity) {
		this.humidity = humidity;
	}

	public double getFall() {
		return fall;
	}

	public void setFall(double fall) {
		this.fall = fall;
	}

	public double getFineDust() {
		return fineDust;
	}

	public void setFineDust(double fineDust) {
		this.fineDust = fineDust;
	}

	public double getUltraFineDust() {
		return ultraFineDust;
	}

	public void setUltraFineDust(double ultraFineDust) {
		this.ultraFineDust = ultraFineDust;
	}

	public int getSky() {
		return sky;
	}

	public void setSky(int sky) {
		this.sky = sky;
	}

	public LocalDateTime getTime() {
		return time;
	}

	public void setTime(LocalDateTime time) {
		this.time = time;
	}
}
