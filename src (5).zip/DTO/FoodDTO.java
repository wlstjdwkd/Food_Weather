package DTO;

import java.io.Serializable;

public class FoodDTO implements Serializable {
	private String name; // varchar2(20)
	private String food_category; // varchar2(20)
	private int weather_good_cnt; // number
	private int weather_rain_cnt; // number
	private int weather_snow_cnt; // number
	private int weather_etc_cnt; // number
	private int finedust_good_cnt; // number
	private int finedust_bad_cnt; // number
	private String image;

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFood_category() {
		return this.food_category;
	}

	public void setFood_category(String food_category) {
		this.food_category = food_category;
	}

	public int getWeather_good_cnt() {
		return this.weather_good_cnt;
	}

	public void setWeather_good_cnt(int weather_good_cnt) {
		this.weather_good_cnt = weather_good_cnt;
	}

	public int getWeather_rain_cnt() {
		return this.weather_rain_cnt;
	}

	public void setWeather_rain_cnt(int weather_rain_cnt) {
		this.weather_rain_cnt = weather_rain_cnt;
	}

	public int getWeather_snow_cnt() {
		return this.weather_snow_cnt;
	}

	public void setWeather_snow_cnt(int weather_snow_cnt) {
		this.weather_snow_cnt = weather_snow_cnt;
	}

	public int getWeather_etc_cnt() {
		return this.weather_etc_cnt;
	}

	public void setWeather_etc_cnt(int weather_etc_cnt) {
		this.weather_etc_cnt = weather_etc_cnt;
	}

	public int getFinedust_good_cnt() {
		return this.finedust_good_cnt;
	}

	public void setFinedust_good_cnt(int finedust_good_cnt) {
		this.finedust_good_cnt = finedust_good_cnt;
	}

	public int getFinedust_bad_cnt() {
		return this.finedust_bad_cnt;
	}

	public void setFinedust_bad_cnt(int finedust_bad_cnt) {
		this.finedust_bad_cnt = finedust_bad_cnt;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
}
