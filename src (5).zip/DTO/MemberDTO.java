package DTO;

import java.io.Serializable;

public class MemberDTO implements Serializable{
    private String mem_id; // varchar2(20)
    private int password; // varchar2(20)
    private String dislikeFood; // varchar2(50)
    private String gender; // char(1)
    private String name; // varchar2(10)
    private String address; // varchar2(50)
    private String phone_num; // varchar2(20)
    private int age; // number

    public int getAge() {
        return this.age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getMem_Id() {
        return this.mem_id;
    }

    public void setMem_Id(String mem_id) {
        this.mem_id = mem_id;
    }

    public int getPassword() {
        return this.password;
    }

    public void setPassword(int password) {
        this.password = password;
    }

    public String getDislikeFood() {
        return this.dislikeFood;
    }

    public void setDislikeFood(String dislikeFood) {
        this.dislikeFood = dislikeFood;
    }

    public String getGender() {
        return this.gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone_num() {
        return this.phone_num;
    }

    public void setPhone_num(String phone_num) {
        this.phone_num = phone_num;
    }
}