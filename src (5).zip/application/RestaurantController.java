package application;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.ResourceBundle;

import DTO.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class RestaurantController implements Initializable {
	@FXML
	private Text txtName;
	@FXML
	private Text txtAddress;
	@FXML
	private Text txtAvg;

	@FXML
	private TextField txtScore;
	@FXML
	private TextField txtReview;
	@FXML
	private Button btnAdd;

	@FXML
	private Text txtCnt;
	@FXML
	private Button btnLeft;
	@FXML
	private Button btnRight;

	@FXML
	private TableView<ReviewDTO> tableView;
	@FXML
	private TableColumn<ReviewDTO, String> tableDate;
	@FXML
	private TableColumn<ReviewDTO, String> tableContent;
	@FXML
	private TableColumn<ReviewDTO, String> tableScore;
	@FXML
	private TableColumn<ReviewDTO, String> tableId;

	public static String gusId;
	public static ObjectOutputStream oos;
	public static ObjectInputStream ois;
	public static Socket RestaurantSocket;
	public static FoodDTO selectFood;
	public static WeatherDTO weatherInfo;
	public static RegionDTO regionInfo;
	private RestaurantDTO[] restaurantList;
	private ObservableList<ReviewDTO> reviewList;
	public static boolean resCheck;

	private int resPointer;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		resCheck = true;
		try {
			HashMap<Object, Object> map = new HashMap<Object, Object>();
			HashMap<Object, Object> returnMap = null;
			Object[] inputData = new Object[2];
			inputData[0] = selectFood;
			inputData[1] = regionInfo;
			map.put("TYPE", "RESTAURANT");
			map.put("CODE", 1);
			map.put("DATA", inputData);

			oos.writeObject(map);
			oos.flush();

			while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
			}

			String type = (String) returnMap.get("TYPE");
			int code = (int) returnMap.get("CODE");
			restaurantList = (RestaurantDTO[]) returnMap.get("DATA");

			if (type.equals("EXIT")) {
				System.out.println("서버 종료");
				return;
			}
			resPointer = 0;
			setRestaurant();

		} catch (ClassNotFoundException | IOException e1) {
			e1.printStackTrace();
		}

		btnLeft.setOnAction(e -> {
			try {
				handleBtnLeftAction(e);
			} catch (ClassNotFoundException | IOException e1) {
				e1.printStackTrace();
			}
		});

		btnRight.setOnAction(e -> {
			try {
				handleBtnRightAction(e);
			} catch (ClassNotFoundException | IOException e1) {
				e1.printStackTrace();
			}
		});

		btnAdd.setOnAction(e -> {
			try {
				handleBtnAddAction(e);
			} catch (ClassNotFoundException | IOException e1) {
				e1.printStackTrace();
			}
		});

		txtScore.setOnMouseClicked(e -> handleTxtClick(e));
		txtReview.setOnMouseClicked(e -> handleTxtClick(e));
	}

	public void handleBtnLeftAction(ActionEvent e) throws IOException, ClassNotFoundException {
		if (resPointer == 0)
			resPointer = restaurantList.length - 1;
		else
			resPointer--;
		setRestaurant();
	}

	public void handleBtnRightAction(ActionEvent e) throws IOException, ClassNotFoundException {
		if (resPointer == restaurantList.length - 1)
			resPointer = 0;
		else
			resPointer++;
		setRestaurant();
	}

	public void handleTxtClick(MouseEvent e) {
		txtScore.setStyle("-fx-text-fill: black;");
		txtReview.setStyle("-fx-text-fill: black;");

	}

	public void handleBtnAddAction(ActionEvent e) throws ClassNotFoundException, IOException {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap = null;

		ReviewDTO inputReview = new ReviewDTO();

		String[] number = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
		String score = txtScore.getText();

		boolean check = true;
		for (int j = 0; j < number.length; j++) {
			if (score.equals(number[j])) {
				check = true;
				break;
			} else {
				check = false;
			}
		}
		if (check) {
			inputReview.setRes_id(restaurantList[resPointer].getRes_id());
			inputReview.setMem_id(gusId);
			inputReview.setReg_date(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yy/MM/dd HH:mm")));
			inputReview.setContent(txtReview.getText());
			inputReview.setRating(Integer.parseInt(txtScore.getText()));
		} else {
			txtScore.setStyle("-fx-text-fill: red;");
			return;
		}

		Object[] data = new Object[3];

		data[0] = inputReview;
		data[1] = selectFood;
		data[2] = weatherInfo;

		map.put("TYPE", "RESTAURANT");
		map.put("CODE", 3);
		map.put("DATA", data);

		oos.writeObject(map);
		oos.flush();

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
		}

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");
		Boolean result = (Boolean) returnMap.get("DATA");

		if (type.equals("EXIT")) {
			System.out.println("서버 종료");
			return;
		}

		if (result) {
			txtScore.setText("");
			txtReview.setText("");
			setRestaurant();
			return;
		} else {
			txtScore.setStyle("-fx-text-fill: red;");
			txtReview.setStyle("-fx-text-fill: red;");
			return;
		}
	}

	public void setRestaurant() throws ClassNotFoundException, IOException {
		if (restaurantList.length < 1) {
			FXMLLoader fail = new FXMLLoader(getClass().getResource("PopupRestaurant.fxml"));
			Parent root = (Parent) fail.load();
			Stage stage = new Stage();
			stage.setTitle("RestaurantInfo");
			stage.setScene(new Scene(root));
			stage.show();

			resCheck = false;
			return;
		}
		txtName.setText(restaurantList[resPointer].getName());
		txtAddress.setText(restaurantList[resPointer].getAddress());
		setReviewList();
		txtAvg.setText(Double.toString(Math.round((restaurantList[resPointer].getAveragerating()) * 10) / 10.0));

	}

	public void setReviewList() throws IOException, ClassNotFoundException {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap = null;

		map.put("TYPE", "RESTAURANT");
		map.put("CODE", 2);
		map.put("DATA", restaurantList[resPointer].getRes_id());

		oos.writeObject(map);
		oos.flush();

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
		}

		reviewList = FXCollections.observableArrayList();

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");
		Object[] inputData = (Object[]) returnMap.get("DATA");

		if (type.equals("EXIT")) {
			System.out.println("서버 종료");
			return;
		}

		txtCnt.setText(Integer.toString((int) inputData[0]));
		reviewList = FXCollections.observableArrayList((ReviewDTO[]) inputData[1]);
		restaurantList[resPointer].setAveragerating((Double) inputData[2]);

		TableColumn tc = tableView.getColumns().get(0);
		tc.setCellValueFactory(new PropertyValueFactory("reg_date"));
		tc = tableView.getColumns().get(1);
		tc.setCellValueFactory(new PropertyValueFactory("content"));
		tc = tableView.getColumns().get(2);
		tc.setCellValueFactory(new PropertyValueFactory("rating"));
		tc = tableView.getColumns().get(3);
		tc.setCellValueFactory(new PropertyValueFactory("mem_id"));

		tableView.setItems(reviewList);
	}
}
