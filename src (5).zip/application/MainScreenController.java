package application;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.ResourceBundle;

import DTO.FoodDTO;
import DTO.MemberDTO;
import DTO.RegionDTO;
import DTO.WeatherDTO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class MainScreenController implements Initializable {

	@FXML
	private TextField txtAdrFirst;
	@FXML
	private TextField txtAdrSecond;
	@FXML
	private TextField txtAdrThird;
	@FXML
	private Button btnAdr;
	@FXML
	private Text txtGusId;
	@FXML
	private Button btnMyPage;
	@FXML
	private Button btnLogOut;
	@FXML
	private Text txtTime;
	@FXML
	private ImageView imgWeather;
	@FXML
	private Text txtTemperature;

	@FXML
	private Text txtWind;
	@FXML
	private Text txtHumidity;
	@FXML
	private Text txtPrecipitation;

	@FXML
	private Text txtFinedust;
	@FXML
	private Text txtFinedustGrade;
	@FXML
	private Text txtUltraFinedust;
	@FXML
	private Text txtUltraFinedustGrade;

	@FXML
	private Text txtFoodName;
	@FXML
	private WebView imgFood;
	@FXML
	private Button btnFoodLeft;
	@FXML
	private Button btnSelectFood;
	@FXML
	private Button btnFoodRight;

	@FXML
	private Text txtDessertName;
	@FXML
	private WebView imgDessert;
	@FXML
	private Button btnDessertLeft;
	@FXML
	private Button btnSelectDessert;
	@FXML
	private Button btnDessertRight;
	@FXML
	private Button btnRecommend;

	public static ObjectOutputStream oos;
	public static ObjectInputStream ois;
	public static Socket MainSocket;
	public static String gusId;
	public static WeatherDTO weatherInfo;
	public static RegionDTO regionInfo;

	private WebEngine foodEngine;
	private WebEngine dessertEngine;
	private int foodPointer;
	private int dessertPointer;

	private FoodDTO[] foodList;
	private FoodDTO[] dessertList;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		txtGusId.setText(gusId);
		foodList = new FoodDTO[3];
		dessertList = new FoodDTO[3];
		foodEngine = imgFood.getEngine();
		dessertEngine = imgDessert.getEngine();
		try {
			HashMap<Object, Object> map = new HashMap<Object, Object>();
			HashMap<Object, Object> returnMap = null;
			MemberDTO user = new MemberDTO();
			user.setMem_Id(gusId);
			map.put("TYPE", "MAIN");
			map.put("CODE", 1);
			map.put("DATA", user);

			oos.writeObject(map);
			oos.flush();

			while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
			}

			String type = (String) returnMap.get("TYPE");
			int code = (int) returnMap.get("CODE");

			RegionDTO region = (RegionDTO) returnMap.get("DATA");
			if (type.equals("EXIT")) {
				System.out.println("서버 종료");
				return;
			}

			regionInfo = region;
			txtAdrFirst.setText(region.getFirstName());
			txtAdrSecond.setText(region.getSecondName());
			txtAdrThird.setText(region.getThirdName());

			setWeatherInfo();
			setFoodInfo();
			setDessertInfo();
		} catch (ClassNotFoundException | IOException e1) {
			e1.printStackTrace();
		}

		btnAdr.setOnAction(e -> {
			try {
				handleBtnAddressAction(e);
			} catch (ClassNotFoundException | IOException e1) {
				e1.printStackTrace();
			}
		});

		btnLogOut.setOnAction(e -> {
			try {
				handleBtnLogOutAction(e);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});

		btnFoodLeft.setOnAction(e -> {
			try {
				handleBtnFoodLeftAction(e);
			} catch (ClassNotFoundException | IOException e1) {
				e1.printStackTrace();
			}
		});

		btnSelectFood.setOnAction(e -> {
			try {
				handleBtnSelectFoodAction(e);
			} catch (IOException | ClassNotFoundException e1) {
				e1.printStackTrace();
			}
		});

		btnFoodRight.setOnAction(e -> {
			try {
				handleBtnFoodRightAction(e);
			} catch (ClassNotFoundException | IOException e1) {
				e1.printStackTrace();
			}
		});

		btnDessertLeft.setOnAction(e -> {
			try {
				handleBtnDessertLeftAction(e);
			} catch (ClassNotFoundException | IOException e1) {
				e1.printStackTrace();
			}
		});

		btnSelectDessert.setOnAction(e -> {
			try {
				handleBtnSelectDessertAction(e);
			} catch (IOException | ClassNotFoundException e1) {
				e1.printStackTrace();
			}
		});

		btnDessertRight.setOnAction(e -> {
			try {
				handleBtnDessertRightAction(e);
			} catch (ClassNotFoundException | IOException e1) {
				e1.printStackTrace();
			}
		});

		btnRecommend.setOnAction(e -> {
			try {
				handleBtnRecommendFoodAction(e);
			} catch (ClassNotFoundException | IOException e1) {
				e1.printStackTrace();
			}
		});

		btnMyPage.setOnAction(e -> {
			try {
				handleBtnMyInfoAction(e);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
	}

	public void handleBtnMyInfoAction(ActionEvent e) throws IOException {
		MyInfoController.InfoSocket = MainSocket;
		MyInfoController.oos = oos;
		MyInfoController.ois = ois;
		MyInfoController.gusId = gusId;

		FXMLLoader myInfo = new FXMLLoader(getClass().getResource("MyInfo.fxml"));
		Parent root = (Parent) myInfo.load();
		Stage stage = new Stage();
		stage.setTitle("MyInfo");
		stage.setScene(new Scene(root));

		stage.show();
	}

	public void handleBtnAddressAction(ActionEvent e) throws IOException, ClassNotFoundException {
		regionInfo = new RegionDTO();
		regionInfo.setFirstName(txtAdrFirst.getText());
		regionInfo.setSecondName(txtAdrSecond.getText());
		regionInfo.setThirdName(txtAdrThird.getText());
		setWeatherInfo();
		setFoodInfo();
		setDessertInfo();
	}

	public void handleBtnLogOutAction(ActionEvent e) throws IOException {
		LogInController.LoginSocket = MainSocket;
		LogInController.oos = oos;
		LogInController.ois = ois;

		Stage completestage = (Stage) btnLogOut.getScene().getWindow();
		completestage.close();
		FXMLLoader login = new FXMLLoader(getClass().getResource("LogIn.fxml"));
		Parent root = (Parent) login.load();
		Stage stage = new Stage();
		stage.setTitle("LogIn");
		stage.setScene(new Scene(root));

		stage.show();
	}

	public void handleBtnFoodLeftAction(ActionEvent e) throws IOException, ClassNotFoundException {
		if (foodPointer == 0)
			foodPointer = foodList.length - 1;
		else
			foodPointer--;
		txtFoodName.setText(foodList[foodPointer].getName());
		foodEngine.load(foodList[foodPointer].getImage());
	}

	public void handleBtnFoodRightAction(ActionEvent e) throws IOException, ClassNotFoundException {
		if (foodPointer == foodList.length - 1)
			foodPointer = 0;
		else
			foodPointer++;
		txtFoodName.setText(foodList[foodPointer].getName());
		foodEngine.load(foodList[foodPointer].getImage());
	}

	public void handleBtnSelectFoodAction(ActionEvent e) throws IOException, ClassNotFoundException {
		RestaurantController.RestaurantSocket = MainSocket;
		RestaurantController.oos = oos;
		RestaurantController.ois = ois;
		RestaurantController.gusId = gusId;
		RestaurantController.selectFood = foodList[foodPointer];
		RestaurantController.weatherInfo = weatherInfo;
		RestaurantController.regionInfo = regionInfo;

		FXMLLoader restaurant = new FXMLLoader(getClass().getResource("Restaurant.fxml"));
		Parent root = (Parent) restaurant.load();
		Stage stage = new Stage();
		stage.setTitle("RestaurantInfo");
		stage.setScene(new Scene(root));
		if (RestaurantController.resCheck)
			stage.show();
	}

	public void handleBtnDessertLeftAction(ActionEvent e) throws IOException, ClassNotFoundException {
		if (dessertPointer == 0)
			dessertPointer = dessertList.length - 1;
		else
			dessertPointer--;
		txtDessertName.setText(dessertList[dessertPointer].getName());
		dessertEngine.load(dessertList[dessertPointer].getImage());
	}

	public void handleBtnDessertRightAction(ActionEvent e) throws IOException, ClassNotFoundException {
		if (dessertPointer == dessertList.length - 1)
			dessertPointer = 0;
		else
			dessertPointer++;
		txtDessertName.setText(dessertList[dessertPointer].getName());
		dessertEngine.load(dessertList[dessertPointer].getImage());
	}

	public void handleBtnSelectDessertAction(ActionEvent e) throws IOException, ClassNotFoundException {
		RestaurantController.RestaurantSocket = MainSocket;
		RestaurantController.oos = oos;
		RestaurantController.ois = ois;
		RestaurantController.gusId = gusId;
		RestaurantController.selectFood = dessertList[dessertPointer];
		RestaurantController.weatherInfo = weatherInfo;
		RestaurantController.regionInfo = regionInfo;

		FXMLLoader restaurant = new FXMLLoader(getClass().getResource("Restaurant.fxml"));
		Parent root = (Parent) restaurant.load();
		Stage stage = new Stage();
		stage.setTitle("RestaurantInfo");
		stage.setScene(new Scene(root));
		if (RestaurantController.resCheck)
			stage.show();
	}

	public void handleBtnRecommendFoodAction(ActionEvent e) throws IOException, ClassNotFoundException {
		RecommendFoodController.RecommendSocket = MainSocket;
		RecommendFoodController.oos = oos;
		RecommendFoodController.ois = ois;
		RecommendFoodController.weatherInfo = weatherInfo;

		FXMLLoader recommend = new FXMLLoader(getClass().getResource("RecommendFood.fxml"));
		Parent root = (Parent) recommend.load();
		Stage stage = new Stage();
		stage.setTitle("Recommend");
		stage.setScene(new Scene(root));

		stage.show();
	}

	public void setWeatherInfo() throws IOException, ClassNotFoundException {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap = null;

		map.put("TYPE", "MAIN");
		map.put("CODE", 2);
		map.put("DATA", regionInfo);

		System.out.println("지역 정보 전송");
		oos.writeObject(map);
		oos.flush();

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
			System.out.println(0);
		}

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");
		WeatherDTO info = (WeatherDTO) returnMap.get("DATA");
		if (type.equals("EXIT")) {
			System.out.println("서버 종료");
			return;
		}
		weatherInfo = info;
		String fineDustGrade = null;
		String ultraFineDustGrade = null;

		if (info.getFineDust() <= 30) {
			fineDustGrade = "좋음";
		} else if (info.getFineDust() > 30 && info.getFineDust() <= 80) {
			fineDustGrade = "보통";
		} else if (info.getFineDust() > 80 && info.getFineDust() <= 150) {
			fineDustGrade = "나쁨";
		} else if (info.getFineDust() > 151) {
			fineDustGrade = "매우 나쁨";
		}

		if (info.getUltraFineDust() <= 15) {
			ultraFineDustGrade = "좋음";
		} else if (info.getUltraFineDust() > 15 && info.getUltraFineDust() <= 35) {
			ultraFineDustGrade = "보통";
		} else if (info.getUltraFineDust() > 35 && info.getUltraFineDust() <= 75) {
			ultraFineDustGrade = "나쁨";
		} else if (info.getUltraFineDust() > 75) {
			ultraFineDustGrade = "매우 나쁨";
		}

		txtTemperature.setText(Double.toString(info.getTemperature()));
		txtWind.setText(Double.toString(info.getWindSpeed()));
		txtHumidity.setText(Double.toString(info.getHumidity()));
		txtPrecipitation.setText(Double.toString(info.getFall()));
		txtFinedust.setText(Double.toString(info.getFineDust()));
		txtFinedustGrade.setText(fineDustGrade);
		txtUltraFinedust.setText(Double.toString(info.getUltraFineDust()));
		txtUltraFinedustGrade.setText(ultraFineDustGrade);
		txtTime.setText(info.getTime().format(DateTimeFormatter.ofPattern("MM월 dd일 HH:mm")));

		String img = "Sunny.png";
		switch (weatherInfo.getSky() / 10) {
		case 1: // 맑음
		case 2:
			img = "Sunny.png";
			break;
		case 3: // 구름많음
			img = "Cloudy.png";
			break;
		case 4: // 흐림
			img = "SemiCloudy.png";
			break;
		default:
			break;
		}
		switch (weatherInfo.getSky() % 10) {
		case 0:
			break;
		case 1:
		case 4:
		case 5:
			img = "Rainy.png";
			break;
		case 2:
		case 3:
		case 6:
		case 7:
			img = "Snowy.png";
			break;
		default:
			break;
		}

		imgWeather.setImage(new Image(getClass().getResource(img).toString()));

		return;
	}

	void setFoodInfo() throws IOException, ClassNotFoundException {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap = null;
		Object[] info = new Object[3];
		info[0] = (String) gusId;
		info[1] = (Integer) weatherInfo.getSky();
		if ((Double.parseDouble(txtFinedust.getText()) > 80) || (Double.parseDouble(txtUltraFinedust.getText()) > 35)) {
			info[2] = true; // 미세먼지 많음
		} else
			info[2] = false;
		map.put("TYPE", "MAIN");
		map.put("CODE", 3);
		map.put("DATA", info);

		System.out.println("날씨 정보 전송");
		oos.writeObject(map);
		oos.flush();

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
		}

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");
		foodList = (FoodDTO[]) returnMap.get("DATA");
		if (type.equals("EXIT")) {
			System.out.println("서버 종료");
			return;
		}

		foodPointer = 0;
		foodEngine.load(foodList[foodPointer].getImage());
		txtFoodName.setText(foodList[foodPointer].getName());
		return;
	}

	void setDessertInfo() throws IOException, ClassNotFoundException {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap = null;
		Object[] info = new Object[3];
		info[0] = (String) gusId;
		info[1] = (Integer) weatherInfo.getSky();
		if ((Double.parseDouble(txtFinedust.getText()) > 80) || (Double.parseDouble(txtUltraFinedust.getText()) > 35)) {
			info[2] = true; // 미세먼지 많음
		} else
			info[2] = false;
		map.put("TYPE", "MAIN");
		map.put("CODE", 4);
		map.put("DATA", info);

		System.out.println("날씨 정보 전송");
		oos.writeObject(map);
		oos.flush();

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
			System.out.println(0);
		}

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");
		dessertList = (FoodDTO[]) returnMap.get("DATA");
		if (type.equals("EXIT")) {
			System.out.println("서버 종료");
			return;
		}

		dessertPointer = 0;
		dessertEngine.load(dessertList[dessertPointer].getImage());
		txtDessertName.setText(dessertList[dessertPointer].getName());
		return;
	}
}
