package application;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.sql.Connection;
import java.util.HashMap;
import java.util.ResourceBundle;

import DTO.MemberDTO;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;

public class LogInController implements Initializable {
	@FXML
	private TextField txtID;
	@FXML
	private PasswordField txtPWD;
	@FXML
	private Text txtLoading;
	@FXML
	private Button btnLogin;
	@FXML
	private Button btnSignUp;
	@FXML
	private Button btnFindIDPWD;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnSignUp.setOnAction(e -> handleBtnSignUpAction(e));
	}

	public static ObjectOutputStream oos;
	public static ObjectInputStream ois;
	public static Socket LoginSocket;

	public void handleBtnLoginAction(ActionEvent e) throws IOException, ClassNotFoundException, EOFException {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap = null;
		MemberDTO member = new MemberDTO();
		member.setMem_Id(txtID.getText());
		member.setPassword(txtPWD.getText().hashCode());

		map.put("TYPE", "LOGIN");
		map.put("CODE", 1);
		map.put("DATA", member);

		oos.writeObject(map);
		oos.flush();

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
		}

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");
		switch (type) {
		case "LOGIN_RES":
			System.out.println("서버가 로그인 결과 전송.");
			switch (code) {
			case 1: {
				System.out.println("로그인 성공");
				try {
					MainScreenController.gusId = txtID.getText();
					MainScreenController.MainSocket = LoginSocket;
					MainScreenController.oos = oos;
					MainScreenController.ois = ois;

					Stage loginstage = (Stage) btnLogin.getScene().getWindow();
					loginstage.close();
					FXMLLoader mainScreen = new FXMLLoader(getClass().getResource("MainScreen.fxml"));
					Parent root = (Parent) mainScreen.load();
					Stage stage = new Stage();
					stage.setTitle("MainScreen");
					stage.setScene(new Scene(root));
					stage.show();

				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
				break;
			case 2: {
				try {
					FXMLLoader fail = new FXMLLoader(getClass().getResource("LogInFailed.fxml"));
					Parent root = (Parent) fail.load();
					Stage stage = new Stage();
					stage.setTitle("Login Failed(Wrong PassWord or Unknown User)");
					stage.setScene(new Scene(root));
					stage.show();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
				break;
			}
		}
	}

	public void handleBtnFindAction(ActionEvent e) {
		try {
			Stage loginstage = (Stage) btnSignUp.getScene().getWindow();
			loginstage.close();
			FXMLLoader find = new FXMLLoader(getClass().getResource("FindIdPwd.fxml"));
			Parent root = (Parent) find.load();
			Stage stage = new Stage();
			stage.setTitle("FindId/Pwd");
			stage.setScene(new Scene(root));
			FindIdPwdController.FindSocket = LoginSocket;
			FindIdPwdController.oos = oos;
			FindIdPwdController.ois = ois;
			stage.show();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void handleBtnSignUpAction(ActionEvent e) {
		try {
			Stage loginstage = (Stage) btnSignUp.getScene().getWindow();
			loginstage.close();
			FXMLLoader signup = new FXMLLoader(getClass().getResource("SignUp.fxml"));
			Parent root = (Parent) signup.load();
			Stage stage = new Stage();
			stage.setTitle("SignUp");
			stage.setScene(new Scene(root));
			SignUpController.SignSocket = LoginSocket;
			SignUpController.oos = oos;
			SignUpController.ois = ois;
			stage.show();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void handleBtnCancelAction(ActionEvent e) throws IOException {
		ObjectOutputStream oos = new ObjectOutputStream(LoginSocket.getOutputStream());

		HashMap<Object, Object> map = new HashMap<Object, Object>();

		map.put("TYPE", "EXIT");
		map.put("CODE", 0);

		oos.writeObject(map);
		oos.flush();

		Platform.exit();
	}
}