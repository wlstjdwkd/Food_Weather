package application;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;

import DTO.MemberDTO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;

public class SignUpController implements Initializable {
	@FXML
	private TextField txtId;
	@FXML
	private TextField txtPwd;
	@FXML
	private TextField txtName;
	@FXML
	private TextField txtSecond;
	@FXML
	private TextField txtLast;
	@FXML
	private TextField txtAdr;
	@FXML
	private TextField txtFood;
	@FXML
	private Text txtError;
	@FXML
	private BorderPane SignUp;
	@FXML
	private Button btnCommit;
	@FXML
	private Button btnCancle;
	@FXML
	private ComboBox comboAge;
	@FXML
	private ComboBox comboGender;
	@FXML
	private ComboBox comboFphone;

	public static Socket SignSocket;
	public static ObjectOutputStream oos;
	public static ObjectInputStream ois;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnCommit.setOnAction(e -> {
			try {
				handleBtnSignAction(e);
			} catch (IOException | ClassNotFoundException e1) {
				e1.printStackTrace();
			}
		});
		comboAge.setItems(ageList);
		comboGender.setItems(genderList);
		comboFphone.setItems(fPhoneList);
	}

	public void handleBtnSignAction(ActionEvent e) throws IOException, ClassNotFoundException {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap;

		MemberDTO member = new MemberDTO();
		member.setMem_Id(txtId.getText());
		member.setPassword(txtPwd.getText().hashCode());
		member.setName(txtName.getText());
		member.setAge(Integer.valueOf((String) comboAge.getValue()));
		switch (String.valueOf(comboGender.getValue())) {
		case "남자":
			member.setGender("M");
			break;
		case "여자":
			member.setGender("F");
			break;
		}
		member.setPhone_num(String.valueOf(comboFphone.getValue()) + txtSecond.getText() + txtLast.getText());
		member.setAddress(txtAdr.getText());
		member.setDislikeFood(txtFood.getText());
		map.put("TYPE", "SIGN_UP");
		map.put("CODE", 1);
		map.put("DATA", member);

		oos.writeObject(map);
		oos.flush();

		// 프로토콜작업

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
		}

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");

		switch (type) {
		case "SIGN_UP_RES":
			System.out.println("서버가 회원가입 결과 전송.");
			switch (code) {
			case 1:
				System.out.println("가입 성공");
				try {
					Stage accountstage = (Stage) btnCommit.getScene().getWindow();
					accountstage.close();
					FXMLLoader login = new FXMLLoader(getClass().getResource("SignUpComplete.fxml"));
					Parent root = (Parent) login.load();
					Stage stage = new Stage();
					stage.setTitle("LogIn");
					stage.setScene(new Scene(root));
					SignUpCompleteController.SignCompleteSocket = SignSocket;
					SignUpCompleteController.oos = oos;
					SignUpCompleteController.ois = ois;
					stage.show();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				break;
			case 2:
				System.out.println("ID중복으로 인한 가입 실패");
				txtError.setText("ID 중복입니다.");
				break;
			}
		case "EXIT":
			System.out.println("서버 종료");
			return;
		}
	}

	private ObservableList<String> ageList = FXCollections.observableArrayList("14", "15", "16", "17", "18", "19", "20",
			"21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38",
			"39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56",
			"57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74",
			"75", "76", "77", "78", "79", "80");

	private ObservableList<String> genderList = FXCollections.observableArrayList("남자", "여자");

	private ObservableList<String> fPhoneList = FXCollections.observableArrayList("010", "011");

	public void handleBtnCancle(ActionEvent event) {
		try {
			Stage loginstage = (Stage) btnCancle.getScene().getWindow();
			loginstage.close();
			FXMLLoader login = new FXMLLoader(getClass().getResource("LogIn.fxml"));
			Parent root = (Parent) login.load();
			Stage stage = new Stage();
			stage.setTitle("LogIn");
			stage.setScene(new Scene(root));
			LogInController.LoginSocket = SignSocket;
			LogInController.oos = oos;
			LogInController.ois = ois;
			stage.show();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
