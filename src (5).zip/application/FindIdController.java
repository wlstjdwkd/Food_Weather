package application;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;

import DTO.MemberDTO;
import DTO.RegionDTO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class FindIdController implements Initializable {

	@FXML
	private BorderPane FindId;
	@FXML
	private TextField txtSphone;
	@FXML
	private TextField txtLphone;
	@FXML
	private ComboBox comboFphone;
	@FXML
	private Text txtId;
	@FXML
	private Button btnFindId;
	@FXML
	private Button btnCancle;

	private ObservableList<String> fPhoneList = FXCollections.observableArrayList("010", "011");

	public static ObjectOutputStream oos;
	public static ObjectInputStream ois;
	public static Socket FindIdSocket;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		comboFphone.setItems(fPhoneList);
	}

	public void handleBtnFindId(ActionEvent event) throws IOException, ClassNotFoundException {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap = null;
		MemberDTO member = new MemberDTO();
		member.setPhone_num(comboFphone.getValue().toString() + txtSphone.getText() + txtLphone.getText());

		map.put("TYPE", "FIND");
		map.put("CODE", 1);
		map.put("DATA", member);

		System.out.println("전화번호 전송");
		oos.writeObject(map);
		oos.flush();

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
		}

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");
		String resId = (String) returnMap.get("DATA");

		switch (type) {
		case "FIND_ID_RES":
			System.out.println("서버가 ID찾기 결과 전송.");
			switch (code) {
			case 1:	//성공
				txtId.setText(resId);
				break;
			case 2:	//실패
				txtId.setText("존재하지 않는 고객입니다.");
				break;
			}
		case "EXIT":
			System.out.println("서버 종료");
			return;
		}
	}

	public void handleBtnCancle(ActionEvent event) throws IOException {
		Stage idfindstage = (Stage) btnCancle.getScene().getWindow();
		idfindstage.close();
		FXMLLoader login = new FXMLLoader(getClass().getResource("LogIn.fxml"));
		Parent root = (Parent) login.load();
		Stage stage = new Stage();
		stage.setTitle("LogIn");
		stage.setScene(new Scene(root));
		LogInController.LoginSocket = FindIdSocket;
		LogInController.oos = oos;
		LogInController.ois = ois;
		stage.show();
	}
}
