package application;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class SignUpCompleteController implements Initializable {
	@FXML
	private BorderPane SignUpComplete;
	@FXML
	private Button btnCommit;

	public static Socket SignCompleteSocket;
	public static ObjectOutputStream oos;
	public static ObjectInputStream ois;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnCommit.setOnAction(e -> {
			try {
				handleBtnCommitAction(e);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
	}

	public void handleBtnCommitAction(ActionEvent e) throws IOException {
		Stage completestage = (Stage) btnCommit.getScene().getWindow();
		completestage.close();
		FXMLLoader login = new FXMLLoader(getClass().getResource("LogIn.fxml"));
		Parent root = (Parent) login.load();
		Stage stage = new Stage();
		stage.setTitle("LogIn");
		stage.setScene(new Scene(root));
		LogInController.LoginSocket = SignCompleteSocket;
		LogInController.oos = oos;
		LogInController.ois = ois;
		stage.show();

	}
}
