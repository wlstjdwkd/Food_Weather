package application;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;

import DTO.MemberDTO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;

public class MyInfoController implements Initializable {
	@FXML
	private TextField txtId;
	@FXML
	private TextField txtName;
	@FXML
	private TextField txtAge;
	@FXML
	private ComboBox comboGender;
	@FXML
	private ComboBox comboFirstPhone;
	@FXML
	private TextField txtSecondPhone;
	@FXML
	private TextField txtThirdPhone;
	@FXML
	private TextField txtDislikeFood;
	@FXML
	private TextField txtAdr;
	@FXML
	private Text txtError;
	@FXML
	private BorderPane SignUp;
	@FXML
	private Button btnCommit;

	public static Socket InfoSocket;
	public static ObjectOutputStream oos;
	public static ObjectInputStream ois;
	public static String gusId;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap;

		try {
			map.put("TYPE", "CHANGE_INFO");
			map.put("CODE", 1);
			map.put("DATA", gusId);

			oos.writeObject(map);
			oos.flush();

			while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
			}
			// 프로토콜작업

			String type = (String) returnMap.get("TYPE");
			int code = (int) returnMap.get("CODE");

			switch (type) {
			case "DISPLAY_INFO_RES":
				switch (code) {
				case 1:
					MemberDTO memberInfo = (MemberDTO) returnMap.get("DATA");
					txtId.setText(memberInfo.getMem_Id());
					txtName.setText(memberInfo.getName());
					txtAge.setText(Integer.toString(memberInfo.getAge()));
					switch (memberInfo.getGender()) {
					case "M":
						comboGender.setValue("남자");
						break;
					case "F":
						comboGender.setValue("여자");
						break;
					}
					txtDislikeFood.setText(memberInfo.getDislikeFood());
					txtAdr.setText(memberInfo.getAddress());
					comboFirstPhone.setValue(memberInfo.getPhone_num().substring(0,3));
					txtSecondPhone.setText(memberInfo.getPhone_num().substring(3,7));
					txtThirdPhone.setText(memberInfo.getPhone_num().substring(7));
					
					break;
				}
				break;
			case "EXIT":
				System.out.println("서버 종료");
				return;
			}

		} catch (IOException |

				ClassNotFoundException e2) {
			e2.printStackTrace();
		}

		btnCommit.setOnAction(e -> {
			try {
				handleBtnSignAction(e);
			} catch (IOException | ClassNotFoundException e1) {
				e1.printStackTrace();
			}
		});

		comboGender.setItems(genderList);
		comboFirstPhone.setItems(fPhoneList);
	}

	public void handleBtnSignAction(ActionEvent e) throws IOException, ClassNotFoundException {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap;

		MemberDTO member = new MemberDTO();
		member.setMem_Id(txtId.getText());
		member.setName(txtName.getText());
		member.setAge(Integer.parseInt(txtAge.getText()));
		switch (String.valueOf(comboGender.getValue())) {
		case "남자":
			member.setGender("M");
			break;
		case "여자":
			member.setGender("F");
			break;
		}
		member.setPhone_num(
				String.valueOf(comboFirstPhone.getValue()) + txtSecondPhone.getText() + txtThirdPhone.getText());
		member.setAddress(txtAdr.getText());
		member.setDislikeFood(txtDislikeFood.getText());
		
		
		
		map.put("TYPE", "CHANGE_INFO");
		map.put("CODE", 2);
		map.put("DATA", member);

		oos.writeObject(map);
		oos.flush();

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
		} // 프로토콜작업

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");

		switch (type) {
		case "CHANGE_INFO_RES":
			System.out.println("서버가 회원가입 결과 전송.");
			switch (code) {
			case 1:
				System.out.println("수정 성공");
				txtError.setText("정보 수정에 성공했습니다.");
				break;
			case 2:
				System.out.println("오류");
				txtError.setText("알수없는오류");
				break;
			}
		case "EXIT":
			System.out.println("서버 종료");
			return;
		}
	}

	private ObservableList<String> genderList = FXCollections.observableArrayList("남자", "여자");

	private ObservableList<String> fPhoneList = FXCollections.observableArrayList("010", "011");

}
