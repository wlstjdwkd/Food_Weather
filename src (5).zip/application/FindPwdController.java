package application;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;

import DTO.MemberDTO;
import DTO.RegionDTO;
import application.*;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.text.Text;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class FindPwdController implements Initializable {
	@FXML
	private BorderPane FindPwd;
	@FXML
	private TextField txtId;
	@FXML
	private ComboBox comboFphone;
	@FXML
	private TextField txtSphone;
	@FXML
	private TextField txtLphone;
	@FXML
	private Text txtResult;
	@FXML
	private Button btnPwd;
	@FXML
	private Button btnCancle;

	public static ObjectOutputStream oos;
	public static ObjectInputStream ois;
	public static Socket FindPwdSocket;

	private ObservableList<String> fPhoneList = FXCollections.observableArrayList("010", "011");

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		comboFphone.setItems(fPhoneList);
	}

	public void handleBtnFindPwd(ActionEvent event) throws IOException, ClassNotFoundException {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap = null;
		MemberDTO member = new MemberDTO();
		member.setMem_Id(txtId.getText());
		member.setPhone_num(comboFphone.getValue().toString() + txtSphone.getText() + txtLphone.getText());

		map.put("TYPE", "FIND");
		map.put("CODE", 2);
		map.put("DATA", member);

		System.out.println("ID, 이름전송");
		oos.writeObject(map);
		oos.flush();

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
		}

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");

		switch (type) {
		case "FIND_PWD_RES":
			System.out.println("서버가 PWD찾기 결과 전송.");
			switch (code) {
			case 1: // 성공
				ChangePwdController.ChangePwdSocket = FindPwdSocket;
				ChangePwdController.oos = oos;
				ChangePwdController.ois = ois;
				ChangePwdController.gusId = txtId.getText();

				Stage pwdfindstage = (Stage) btnPwd.getScene().getWindow();
				pwdfindstage.close();
				FXMLLoader changePwd = new FXMLLoader(getClass().getResource("ChangePwd.fxml"));
				Parent root = (Parent) changePwd.load();
				Stage stage = new Stage();
				stage.setTitle("ChangePwd");
				stage.setScene(new Scene(root));

				stage.show();

				break;
			case 2: // 실패
				txtResult.setText("존재하지 않는 고객입니다.");
				break;
			}
			break;
		case "EXIT":
			System.out.println("서버 종료");
			return;
		}
	}

	public void handleBtnCancle(ActionEvent event) throws IOException {
		LogInController.LoginSocket = FindPwdSocket;
		LogInController.oos = oos;
		LogInController.ois = ois;

		Stage idfindstage = (Stage) btnCancle.getScene().getWindow();
		idfindstage.close();
		FXMLLoader login = new FXMLLoader(getClass().getResource("LogIn.fxml"));
		Parent root = (Parent) login.load();
		Stage stage = new Stage();
		stage.setTitle("LogIn");
		stage.setScene(new Scene(root));

		stage.show();
	}
}
