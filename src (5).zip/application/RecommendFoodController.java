package application;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;

import DTO.FoodDTO;
import DTO.WeatherDTO;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.control.ComboBox;

public class RecommendFoodController implements Initializable {

	@FXML
	private ComboBox comboClass;
	@FXML
	private Button btnAdd;
	@FXML
	private TextField txtFoodName;
	@FXML
	private Text txtResult;

	public static Socket RecommendSocket;
	public static ObjectOutputStream oos;
	public static ObjectInputStream ois;
	public static WeatherDTO weatherInfo;

	private ObservableList<String> list = FXCollections.observableArrayList("식사", "디저트");

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		comboClass.setItems(list);
		btnAdd.setOnAction(e -> {
			try {
				handleBtnRecommendFood(e);
			} catch (ClassNotFoundException | IOException e1) {
				e1.printStackTrace();
			}
		});
		txtResult.setText("");
	}

	public void handleBtnRecommendFood(ActionEvent e) throws IOException, ClassNotFoundException, EOFException {
		FoodDTO food = new FoodDTO();
		food.setFood_category(String.valueOf(comboClass.getValue()));
		food.setName(txtFoodName.getText());

		if ((txtFoodName.getText().isEmpty()) && (String.valueOf(comboClass.getValue()).isEmpty())) {
			txtResult.setText("정보를 입력해 주세요");
			return;
		}

		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap = null;

		Object[] data = new Object[2];
		data[0] = food;
		data[1] = weatherInfo;

		map.put("TYPE", "RECOMMEND_FOOD");
		map.put("CODE", 1);
		map.put("DATA", data);

		System.out.println("추천 음식 정보 전송");
		oos.writeObject(map);
		oos.flush();

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
		}

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");
		boolean result = (boolean) returnMap.get("DATA");

		if (result) {
			txtResult.setText("신규 음식 등록(3초 후 창 닫힘)");
		} else {
			txtResult.setText("기존 음식 추천(3초 후 창 닫힘)");
		}

		new Timeline(new KeyFrame(Duration.millis(3000), ae -> {
			Stage stage = (Stage) txtResult.getScene().getWindow();
			stage.close();
		})).play();

	}
}
