package application;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import DTO.*;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ChangePwdController implements Initializable {
	@FXML
	private TextField txtNewPwd;
	@FXML
	private TextField txtCheckNewPwd;
	@FXML
	private Button btnPwd;
	@FXML
	private Button btnCancle;
	@FXML
	private Text txtInconsistency;

	public static ObjectOutputStream oos;
	public static ObjectInputStream ois;
	public static Socket ChangePwdSocket;
	public static String gusId;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnPwd.setOnAction(e -> {
			try {
				handleBtnChangePwd(e);
			} catch (IOException | ClassNotFoundException e1) {
				e1.printStackTrace();
			}
		});
		btnCancle.setOnAction(e -> {
			try {
				handleBtnCancle(e);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
		// btnCancle.setOnAction(e);
	}

	public void handleBtnChangePwd(ActionEvent e) throws IOException, ClassNotFoundException {
		HashMap<Object, Object> map = new HashMap<Object, Object>();
		HashMap<Object, Object> returnMap = null;
		MemberDTO member = new MemberDTO();
		if (txtNewPwd.getText().equals(txtCheckNewPwd.getText())) {
			member.setMem_Id(gusId);
			member.setPassword(txtNewPwd.getText().hashCode());
		} else {// 새 비밀번호랑 비밀번호 확인이랑 안맞을 때
			txtInconsistency.setText("비밀번호 불일치");
			return;
		}

		map.put("TYPE", "CHANGE");
		map.put("CODE", 1);
		map.put("DATA", member);

		oos.writeObject(map);
		oos.flush();
		System.out.println("PWD 변경 요청 전송.");

		while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
		}

		String type = (String) returnMap.get("TYPE");
		int code = (int) returnMap.get("CODE");

		switch (type) {
		case "CHANGE_RES":
			System.out.println("서버가 PWD 변경 결과 전송.");
			switch (code) {
			case 1: // 성공
				txtInconsistency.setText("비밀번호 변경 성공(3초 후 창 꺼짐)");
				new Timeline(new KeyFrame(Duration.millis(3000), ae -> {
					try {
						handleBtnCancle(e);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				})).play();
				break;
			case 2: // 실패
				txtInconsistency.setText("비밀번호 변경 실패(알수없는원인)");
				break;
			}
			break;
		case "EXIT":
			System.out.println("서버 종료");
			return;
		}

	}

	public void handleBtnCancle(ActionEvent e) throws IOException {
		Stage idfindstage = (Stage) btnCancle.getScene().getWindow();
		idfindstage.close();
		FXMLLoader login = new FXMLLoader(getClass().getResource("LogIn.fxml"));
		Parent root = (Parent) login.load();
		Stage stage = new Stage();
		stage.setTitle("LogIn");
		stage.setScene(new Scene(root));
		LogInController.LoginSocket = ChangePwdSocket;
		LogInController.oos = oos;
		LogInController.ois = ois;
		stage.show();
	}

}