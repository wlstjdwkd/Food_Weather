package server;

import java.io.*;
import java.net.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import org.json.simple.*;
import org.json.simple.parser.*;

import DTO.RegionDTO;

public class ApiSearch {
	static String clientId = "X7vqmFTM62bgf4krQXnd";
	static String clientSecret = "TdbEEPBuP0";
	static int restaurant_cnt = 3;
	static String dustId = "zeoMIQPKW9iK6Qk0mvltA09euzjZplKFaCDXlpYpBYbXfYwB7dt3xpfzss5eXiUCl0gUeNP3DHQ1IN3idm8tAw==";
	static String weatherKey = "%2FhVZrByrplgUWzFq6dygTueh2lCwzRlh63ZiCUeOO0Ln36bKtV8xLxXSJUKK%2FVbuVkL%2BI0a6gDZFGU3EhEHtPA%3D%3D";

	public static DateTimeFormatter DateFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
	public static DateTimeFormatter TimeFormatter = DateTimeFormatter.ofPattern("HHmm");
	public static DateTimeFormatter DTFormatter = DateTimeFormatter.ofPattern("yyyyMMdd HHmm");

	public static void main(String[] args) throws IOException, ParseException {
		RegionDTO sample = new RegionDTO();
		sample.setFirstName("경상북도");
		sample.setSecondName("구미시");
		sample.setThirdName("양포동");
		sample.setX("86");
		sample.setY("96");

		String location = sample.getSecondName() + " " + sample.getThirdName();
		String food = "아이스크림";
		String sum = location + " " + food;

		LocalDateTime testTime = LocalDateTime.of(2021, 5, 29, 0, 20);
		testTime = LocalDateTime.now();
		LocalTime setTime = LocalTime.of(testTime.getHour() / 3 * 3, 0);

		JSONArray weatherArray = getWeather(sample);
		System.out.println("=====Weather=====");
		JSONObject weather;
		String category;
		String day = "";
		for (int i = 0; i < weatherArray.size(); i++) {
			weather = (JSONObject) weatherArray.get(i);
			Object fcstValue = weather.get("fcstValue");
			Object fcstDate = weather.get("fcstDate");
			Object fcstTime = weather.get("fcstTime");
			category = (String) weather.get("category");
			// 출력
			if (!day.equals(fcstDate.toString())) {
				day = fcstDate.toString();
			}
			if (fcstDate.equals((String) testTime.format(DateFormatter))
					&& fcstTime.equals((String) setTime.format(TimeFormatter))) {
				System.out.print("category : " + category);
				System.out.print(", fcst_Value : " + fcstValue);
				System.out.print(", fcstDate : " + fcstDate);
				System.out.println(", fcstTime : " + fcstTime);
			}
		}

		JSONArray dustArray = getDust(sample);
		System.out.println("=====Dust=====");
		for (int i = 0; i < dustArray.size(); i++) {
			JSONObject tempObj = (JSONObject) dustArray.get(i);

			if (tempObj.get("cityName").equals(sample.getSecondName())) {
				System.out.println("도시 : " + tempObj.get("cityName"));
				System.out.println("측정일 : " + tempObj.get("dataTime"));
				System.out.println("미세먼지 pm10 : " + tempObj.get("pm10Value"));
				System.out.println("미세먼지 pm2.5 : " + tempObj.get("pm25Value"));
				System.out.println("----------------------------");
			}
		}

		JSONArray naverArray = getRestaurant(sum);

		System.out.println("=====Naver=====");
		for (int i = 0; i < naverArray.size(); i++) {
			JSONObject tempObj = (JSONObject) naverArray.get(i);
			System.out.println("" + (i + 1) + "번째 가게의 이름 : " + tempObj.get("title"));
			System.out.println("" + (i + 1) + "번째 가게의 종류 : " + tempObj.get("category"));
			System.out.println("" + (i + 1) + "번째 멤버의 주소 : " + tempObj.get("address"));
			System.out.println("----------------------------");
		}

		JSONArray foodArray = getImg("라면");
		System.out.println("=====Food=====");
		for (int i = 0; i < foodArray.size(); i++) {
			JSONObject tempObj = (JSONObject) foodArray.get(i);
			System.out.println("" + (i + 1) + "번째 음식의 링크 : " + tempObj.get("link"));
			System.out.println("----------------------------");
		}
	}

	public static JSONArray getWeather(RegionDTO location) throws IOException, ParseException {
		int calctime = ((LocalTime.now().getHour() / 3 * 3) + 5) % 24;
		System.out.println(calctime);
		LocalTime setTime = LocalTime.of(calctime, 0);

		String nx = location.getX(); // 위도
		String ny = location.getY(); // 경도
		String baseDate = LocalDateTime.now().minusDays(1).plusHours(3).format(DateFormatter);
		String baseTime = setTime.format(TimeFormatter);

		StringBuilder urlBuilder = new StringBuilder(
				"http://apis.data.go.kr/1360000/VilageFcstInfoService/getVilageFcst");
		urlBuilder.append("?" + URLEncoder.encode("ServiceKey", "UTF-8") + "=" + weatherKey);
		urlBuilder.append("&" + URLEncoder.encode("nx", "UTF-8") + "=" + URLEncoder.encode(nx, "UTF-8")); // 경도
		urlBuilder.append("&" + URLEncoder.encode("ny", "UTF-8") + "=" + URLEncoder.encode(ny, "UTF-8")); // 위도
		urlBuilder.append("&" + URLEncoder.encode("base_date", "UTF-8") + "="
				+ URLEncoder.encode(baseDate, "UTF-8")); /* 조회하고싶은 날짜 */
		urlBuilder.append("&" + URLEncoder.encode("base_time", "UTF-8") + "="
				+ URLEncoder.encode(baseTime, "UTF-8")); /* 조회하고싶은 시간 AM 02시부터 3시간 단위 */
		urlBuilder.append(
				"&" + URLEncoder.encode("dataType", "UTF-8") + "=" + URLEncoder.encode("JSON", "UTF-8")); /* 타입 */
		urlBuilder.append("&" + URLEncoder.encode("numOfRows", "UTF-8") + "="
				+ URLEncoder.encode("112", "UTF-8")); /* 한 페이지 결과 수 */

		URL url = new URL(urlBuilder.toString());
		System.out.println(url);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-type", "application/json");
		BufferedReader rd;
		if (conn.getResponseCode() >= HttpURLConnection.HTTP_OK && conn.getResponseCode() <= 300) {
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		} else {
			rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		}
		StringBuilder sb = new StringBuilder();
		String line;
		while ((line = rd.readLine()) != null) {
			sb.append(line);
		}
		rd.close();
		conn.disconnect();
		String result = sb.toString();

		JSONParser parser = new JSONParser();
		JSONObject obj = (JSONObject) parser.parse(result);
		JSONObject parse_response = (JSONObject) obj.get("response");
		JSONObject parse_body = (JSONObject) parse_response.get("body");
		JSONObject parse_items = (JSONObject) parse_body.get("items");
		JSONArray parse_item = (JSONArray) parse_items.get("item");

		return parse_item;
	}

	public static JSONArray getDust(RegionDTO location) throws IOException, ParseException {
		String[] list = new String[8];
		list[0] = "특별";
		list[1] = "자치";
		list[2] = "광역";
		list[3] = "시";
		list[4] = "도";
		list[5] = "청";
		list[6] = "라";
		list[7] = "상";
		String first = location.getFirstName();
		for (int i = 0; i < 8; i++) {
			first = first.replace(list[i], "");
		}

		StringBuilder urlBuilder = new StringBuilder(
				"http://apis.data.go.kr/B552584/ArpltnStatsSvc/getCtprvnMesureSidoLIst"); /* URL */
		urlBuilder.append("?" + URLEncoder.encode("ServiceKey", "UTF-8") + dustId); /* Service Key */
		urlBuilder.append("&" + URLEncoder.encode("serviceKey", "UTF-8") + "="
				+ URLEncoder.encode(dustId, "UTF-8")); /* 공공데이터포털에서 받은 인증키 */
		urlBuilder.append("&" + URLEncoder.encode("returnType", "UTF-8") + "="
				+ URLEncoder.encode("json", "UTF-8")); /* xml 또는 json */
		urlBuilder.append("&" + URLEncoder.encode("numOfRows", "UTF-8") + "="
				+ URLEncoder.encode("30", "UTF-8")); /* 한 페이지 결과 수 */
		urlBuilder
				.append("&" + URLEncoder.encode("pageNo", "UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /* 페이지번호 */
		urlBuilder.append(
				"&" + URLEncoder.encode("sidoName", "UTF-8") + "=" + URLEncoder.encode(first, "UTF-8")); /* 시도 이름 */
		urlBuilder.append("&" + URLEncoder.encode("searchCondition", "UTF-8") + "="
				+ URLEncoder.encode("HOUR", "UTF-8")); /* 요청 데이터기간 */
		URL url = new URL(urlBuilder.toString());
		System.out.println(url);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-type", "application/json");
		BufferedReader rd;
		if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		} else {
			rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		}
		StringBuilder sb = new StringBuilder();
		String line;
		while ((line = rd.readLine()) != null) {
			sb.append(line);
		}
		rd.close();
		conn.disconnect();

		String responseBody = sb.toString();

		try {
			JSONParser parser = new JSONParser();
			JSONObject obj = (JSONObject) parser.parse(responseBody);
			JSONObject parse_response = (JSONObject) obj.get("response");
			JSONObject parse_body = (JSONObject) parse_response.get("body");
			JSONArray parse_items = (JSONArray) parse_body.get("items");

			return parse_items;
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}

	}

	public static JSONArray getImg(String sum) {
		String text = null;
		try {
			text = URLEncoder.encode(sum, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException("API 요청과 응답 실패", e);
		}
		String apiURL = "https://openapi.naver.com/v1/search/image?sort=sim&display=1&query=" + text + "&filter=small"; // json
		Map<String, String> requestHeaders = new HashMap<>();
		requestHeaders.put("X-Naver-Client-Id", clientId);
		requestHeaders.put("X-Naver-Client-Secret", clientSecret);
		String responseBody = get(apiURL, requestHeaders);
//		System.out.println(responseBody);
		try {
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObj = (JSONObject) jsonParser.parse(responseBody);
			JSONArray imgArray = (JSONArray) jsonObj.get("items");
			
			return imgArray;

		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static JSONArray getRestaurant(String sum) {
		System.out.println(sum);
		String text = null;
		try {
			text = URLEncoder.encode(sum, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException("API 요청과 응답 실패", e);
		}

		String apiURL = "https://openapi.naver.com/v1/search/local?sort=comment&query=" + text + "&display="
				+ restaurant_cnt;
		Map<String, String> requestHeaders = new HashMap<>();
		requestHeaders.put("X-Naver-Client-Id", clientId);
		requestHeaders.put("X-Naver-Client-Secret", clientSecret);
		String responseBody = get(apiURL, requestHeaders);
		System.out.println(responseBody);
		try {
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObj = (JSONObject) jsonParser.parse(responseBody);
			JSONArray restaurantArray = (JSONArray) jsonObj.get("items");

			return restaurantArray;
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}

	}

	private static String get(String apiUrl, Map<String, String> requestHeaders) {
		HttpURLConnection con = connect(apiUrl);
		try {
			con.setRequestMethod("GET");
			for (Map.Entry<String, String> header : requestHeaders.entrySet()) {
				con.setRequestProperty(header.getKey(), header.getValue());
			}

			int responseCode = con.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) { // 정상 호출
				return readBody(con.getInputStream());
			} else { // 에러 발생
				return readBody(con.getErrorStream());
			}
		} catch (IOException e) {
			throw new RuntimeException("API 요청과 응답 실패", e);
		} finally {
			con.disconnect();
		}
	}

	private static HttpURLConnection connect(String apiUrl) {
		try {
			URL url = new URL(apiUrl);
			return (HttpURLConnection) url.openConnection();
		} catch (MalformedURLException e) {
			throw new RuntimeException("API URL이 잘못되었습니다. : " + apiUrl, e);
		} catch (IOException e) {
			throw new RuntimeException("연결이 실패했습니다. : " + apiUrl, e);
		}
	}

	private static String readBody(InputStream body) {
		InputStreamReader streamReader = new InputStreamReader(body);

		try (BufferedReader lineReader = new BufferedReader(streamReader)) {
			StringBuilder responseBody = new StringBuilder();

			String line;
			while ((line = lineReader.readLine()) != null) {
				responseBody.append(line);
			}

			return responseBody.toString();
		} catch (IOException e) {
			throw new RuntimeException("API 응답을 읽는데 실패했습니다.", e);
		}
	}
}