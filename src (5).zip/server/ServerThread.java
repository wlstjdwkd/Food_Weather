package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import DAO.*;
import DTO.*;
import commonSetting.ConnectSetting;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ServerThread extends Thread {
	// 멤버변수로 선언
	private Socket socket;
	private String userIP;

	ServerThread(Socket s) {
		this.socket = s;
		this.userIP = socket.getInetAddress().toString();
	}

	// 오버라이딩일 경우 throw 불가.
	public void run() {
		try {
			service();
		} catch (IOException | ParseException | ClassNotFoundException e) {
			System.out.println("**" + userIP + "님 접속 종료.");
		} finally {
			try {
				closeAll();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private void service() throws IOException, ParseException, ClassNotFoundException {
		Connection conn = ConnectSetting.getConnection();
		ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
		ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
		boolean program_stop = false;

		while (true) {
			MemberDAO mdao = new MemberDAO();
			FoodDAO fdao = new FoodDAO();
			RegionDAO regdao = new RegionDAO();
			RestaurantDAO resdao = new RestaurantDAO();
			ReviewDAO revdao = new ReviewDAO();

			FoodDTO fdto = null;
			MemberDTO mdto = null;
			ReviewDTO revdto = null;
			RestaurantDTO resdto = null;
			RegionDTO regdto = null;
			WeatherDTO wdto = null;

			HashMap<Object, Object> map = null;
			HashMap<Object, Object> returnMap = null;

			Object[] objectArr = null;

			while ((returnMap = (HashMap<Object, Object>) ois.readObject()) == null) {
				System.out.println(0);
			}
			map = new HashMap<Object, Object>();
			String type = (String) returnMap.get("TYPE");
			int code = (int) returnMap.get("CODE");

			switch (type) {
			case "EXIT": // 프로그램 종료 수신
				System.out.println("클라이언트 종료");
				throw new IOException();
			case "LOGIN":
				switch (code) {
				case 1:
					// 로그인 정보 수신
					mdto = (MemberDTO) returnMap.get("DATA");

					System.out.println("클라이언트가 로그인 정보를 보냈습니다");
					System.out.println(mdto.getMem_Id() + " " + mdto.getPassword());
					boolean loginResult = mdao.loginRequest(mdto);
					try {

						if (loginResult) {
							// 로그인 성공
							map.put("TYPE", "LOGIN_RES");
							map.put("CODE", 1);
							System.out.println("로그인 성공");
						} else { // 로그인 실패
							map.put("TYPE", "LOGIN_RES");
							map.put("CODE", 2);
							System.out.println("암호 틀림");
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					System.out.println("로그인 처리 결과 전송");

					oos.writeObject(map);
					oos.flush();

					break;
				}
				break;
			case "SIGN_UP":
				switch (code) {
				case 1: // code1 회원가입 정보 수신 후 id중복검사, 없을 시DB에 등록 -> code2에 data 성공=0,실패=1 보냄
					System.out.println("클라이언트가 회원가입 정보를 보냈습니다");

					mdto = (MemberDTO) returnMap.get("DATA");

					// id 중복확인
					System.out.println("ID중복확인 시작");
					if (mdao.idCheck(mdto.getMem_Id())) {
						System.out.println("서버DB에 동일한 ID 존재");
						map.put("TYPE", "SIGN_UP_RES");
						map.put("CODE", 2);
						map.put("DATA", "FALSE");
					} else {
						System.out.println("서버DB에 동일한 ID 없음");
						map.put("TYPE", "SIGN_UP_RES");
						map.put("CODE", 1);
						map.put("DATA", "TRUE");
						mdao.insertCustomer(mdto);
					}
					oos.writeObject(map);
					oos.flush();
					System.out.println("회원가입 결과 전송 완료");
					break;
				}
				break;
			case "MAIN":
				switch (code) {
				case 1:
					// 로그인 정보 수신
					System.out.println("클라이언트가 id 정보를 보냈습니다");
					mdto = (MemberDTO) returnMap.get("DATA");
					regdto = new RegionDTO();

					regdto.setFirstName(mdao.addressInfo(mdto.getMem_Id())[0]);
					regdto.setSecondName(mdao.addressInfo(mdto.getMem_Id())[1]);
					regdto.setThirdName(mdao.addressInfo(mdto.getMem_Id())[2]);

					map.put("TYPE", "MAIN_RES");
					map.put("CODE", 1);
					map.put("DATA", regdto);

					System.out.println("지역 정보 전송");
					System.out.println(regdto.getFirstName() + regdto.getSecondName() + regdto.getThirdName());
					oos.writeObject(map);
					oos.flush();
					break;
				case 2:
					System.out.println("지역 정보 수신");
					regdto = (RegionDTO) returnMap.get("DATA");
					String[] translate = null;
					translate = regdao.addressXY(regdto.getFirstName(), regdto.getSecondName(), regdto.getThirdName());
					regdto.setX(translate[0]);
					regdto.setY(translate[1]);
					System.out.println(translate[0] + " " + translate[1]);
					JSONArray weatherArray = ApiSearch.getWeather(regdto);
					JSONArray dustArray = ApiSearch.getDust(regdto);

					LocalTime setTime = LocalTime.of(LocalTime.now().getHour() / 3 * 3, 0);

					double temper = 0, wind = 0, reh = 0, rain = 0, pm10 = 0, pm25 = 0;
					int sky = 0;
					LocalDateTime time = LocalDateTime.of(LocalDate.now(), setTime);
					JSONObject weather;
					String category;
					System.out.println("=====Weather=====");
					for (int i = 0; i < weatherArray.size(); i++) {
						weather = (JSONObject) weatherArray.get(i);
						Object fcstDate = weather.get("fcstDate");
						Object fcstTime = weather.get("fcstTime");
						if (fcstDate.equals((String) LocalDate.now().format(ApiSearch.DateFormatter))
								&& fcstTime.equals((String) setTime.format(ApiSearch.TimeFormatter))) {
							System.out.println(fcstDate + " " + fcstTime);

							category = (String) weather.get("category");
							Object fcstValue = weather.get("fcstValue");
							switch (category) {
							case "T3H":
								temper = Double.parseDouble((String) fcstValue);
								break;
							case "WSD":
								wind = Double.parseDouble((String) fcstValue);
								break;
							case "REH":
								reh = Double.parseDouble((String) fcstValue);
								break;
							case "R06":
								rain = Double.parseDouble((String) fcstValue);
								break;
							case "SKY":
								sky += Integer.parseInt((String) fcstValue) * 10;
								break;
							case "PTY":
								sky += Integer.parseInt((String) fcstValue);
								break;
							default:
								break;
							}
							System.out.println(category + " " + fcstValue);
						}
					}

					System.out.println("=====Dust=====");
					for (int i = 0; i < dustArray.size(); i++) {
						JSONObject tempObj = (JSONObject) dustArray.get(i);

						if (tempObj.get("cityName").equals(regdto.getSecondName())) {
							System.out.println("도시 : " + tempObj.get("cityName"));
							System.out.println("측정일 : " + tempObj.get("dataTime"));
							System.out.println("미세먼지 pm10 : " + tempObj.get("pm10Value"));
							pm10 = Integer.parseInt((String) tempObj.get("pm10Value"));
							System.out.println("미세먼지 pm2.5 : " + tempObj.get("pm25Value"));
							pm25 = Integer.parseInt((String) tempObj.get("pm25Value"));
							System.out.println("----------------------------");
						}
					}

					wdto = new WeatherDTO(temper, wind, reh, rain, pm10, pm25, sky, time);

					map.put("TYPE", "MAIN_RES");
					map.put("CODE", 2);
					map.put("DATA", wdto);

					System.out.println("날씨 정보 전송");
					oos.writeObject(map);
					oos.flush();
					break;
				case 3:
					System.out.println("식사 날씨 정보 수신");
					objectArr = (Object[]) returnMap.get("DATA");
					String memId = (String) objectArr[0];
					int skyInfo = (Integer) objectArr[1];
					FoodDTO[] foodListInfo = null;
					FoodDTO[] foodInfo = new FoodDTO[3];
					String[] dislikeList = mdao.displayDislikefood(memId);
					System.out.println(skyInfo);

					switch (skyInfo % 10) {
					case 0:
						switch (skyInfo / 10) {
						case 1: // 맑음
						case 2:
						case 3: // 구름많음
						case 4: // 흐림
							foodListInfo = fdao.displayGoodWeatherFood();
							break;
						}
						if ((boolean) objectArr[2]) {
							foodListInfo = fdao.displayBadFinedustFood();
						}
						break;
					case 1:
					case 4:
					case 5: // 비
						foodListInfo = fdao.displayRainFood();
						break;
					case 2:
					case 3:
					case 6:
					case 7: // 눈
						foodListInfo = fdao.displaySnowFood();
						break;
					}

					for (int i = 0, k = 0; i < 3; k++) {
						boolean check = true;
						for (int j = 0; j < dislikeList.length; j++) {
							if (foodListInfo[k].getName().equals(dislikeList[j])) {
								check = false;
								break;
							}
						}
						if (check == true) {
							foodInfo[i] = foodListInfo[k];
							if (ApiSearch.getImg(foodInfo[i].getName()).size() > 0) {
								JSONObject foodIMG = (JSONObject) ApiSearch.getImg(foodInfo[i].getName()).get(0);
								foodInfo[i].setImage((String) (foodIMG).get("link"));
							} else
								foodInfo[i].setImage(
										"https://img-premium.flaticon.com/png/512/1174/1174795.png?token=exp=1622997411~hmac=b56c3cffc418ea7ddd38bfbccfa372c9");
							i++;
						}
					}

					map.put("TYPE", "MAIN_RES");
					map.put("CODE", 3);
					map.put("DATA", foodInfo);

					System.out.println("지역 정보 전송");
					oos.writeObject(map);
					oos.flush();

					break;
				case 4:
					System.out.println("디저트 날씨 정보 수신");
					objectArr = (Object[]) returnMap.get("DATA");
					String memId2 = (String) objectArr[0];
					int skyInfo2 = (Integer) objectArr[1];
					FoodDAO fdao2 = new FoodDAO();
					FoodDTO[] dessertListInfo = null;
					FoodDTO[] dessertInfo = new FoodDTO[3];
					String[] dislikeList2 = mdao.displayDislikefood(memId2);
					System.out.println(skyInfo2);
					switch (skyInfo2 / 10) {
					case 1: // 맑음
					case 2:
					case 3: // 구름많음
					case 4: // 흐림
						dessertListInfo = fdao2.displayGoodWeatherDessert();
						break;
					default:
						break;
					}
					if ((boolean) objectArr[2])
						dessertListInfo = fdao2.displayBadFinedustDessert();
					switch (skyInfo2 % 10) {
					case 0:
						break;
					case 1:
					case 4:
					case 5: // 비
						dessertListInfo = fdao2.displayRainDessert();
						break;
					case 2:
					case 3:
					case 6:
					case 7: // 눈
						dessertListInfo = fdao2.displaySnowDessert();
						break;
					default:
						break;
					}

					for (int i = 0, k = 0; i < 3; k++) {
						boolean check = true;
						for (int j = 0; j < dislikeList2.length; j++) {
							if (dessertListInfo[k].getName() == dislikeList2[j]) {
								check = false;
								break;
							}
						}
						if (check == true) {
							dessertInfo[i] = dessertListInfo[k];
							if (ApiSearch.getImg(dessertInfo[i].getName()).size() > 0) {
								JSONObject foodIMG = (JSONObject) ApiSearch.getImg(dessertInfo[i].getName()).get(0);
								dessertInfo[i].setImage((String) (foodIMG).get("link"));
							} else
								dessertInfo[i].setImage(
										"https://img-premium.flaticon.com/png/512/1174/1174795.png?token=exp=1622997411~hmac=b56c3cffc418ea7ddd38bfbccfa372c9");
							i++;

						}
					}

					map.put("TYPE", "MAIN_RES");
					map.put("CODE", 4);
					map.put("DATA", dessertInfo);

					System.out.println("지역 정보 전송");
					oos.writeObject(map);
					oos.flush();

					break;
				}
				break;
			case "RESTAURANT":
				switch (code) {
				case 1:
					objectArr = new Object[2];
					objectArr = (Object[]) returnMap.get("DATA");
					fdto = (FoodDTO) objectArr[0];
					regdto = (RegionDTO) objectArr[1];
					String adrName = regdto.getFirstName() + " " + regdto.getSecondName() + " " + regdto.getThirdName();

					JSONArray resArray = ApiSearch.getRestaurant(adrName + " " + fdto.getName());
					int rescnt = 3;
					if (resArray.size() < 3) {
						rescnt = resArray.size();
					}
					RestaurantDTO[] restaurantList = new RestaurantDTO[rescnt];

					for (int i = 0; i < resArray.size(); i++) {
						JSONObject tempObj = (JSONObject) resArray.get(i);
						resdto = new RestaurantDTO();
						String resName = (String) tempObj.get("title");
						resName = resName.replace("<b>", " ");
						resName = resName.replace("</b>", " ");
						if (resdao.restaurantCheck(resName, (String) tempObj.get("address"))) {
							resdto = resdao.displayRestaurant(resName, (String) tempObj.get("address"));
						} else {
							resdto.setName(resName);
							resdto.setAddress((String) tempObj.get("address"));
							if (((String) tempObj.get("category")).contains("디저트")) {
								resdto.setCategory("디저트");
							} else {
								resdto.setCategory("식사");
							}
							resdto.setAveragerating((Double) 0.0);
							if (resdao.insertRestaurant(resdto)) {
								System.out.println("신규 가게 등록 성공");
							}
						}
						restaurantList[i] = resdao.displayRestaurant(resName, (String) tempObj.get("address"));
					}
					map.put("TYPE", "RESTAURANT_RES");
					map.put("CODE", 1);
					map.put("DATA", restaurantList);

					System.out.println("식당 정보 전송");
					oos.writeObject(map);
					oos.flush();
					break;
				case 2:
					String resId = (String) returnMap.get("DATA");
					double resAver = resdao.displayAverRate(resId);
					int revCnt = revdao.displayReviewNum(resId);
					ReviewDTO[] reviewList = revdao.displayReview(resId);

					objectArr = new Object[3];

					objectArr[0] = revCnt;
					objectArr[1] = reviewList;
					objectArr[2] = resAver;

					map.put("TYPE", "RESTAURANT_RES");
					map.put("CODE", 2);
					map.put("DATA", objectArr);

					System.out.println("식당 리뷰 정보 전송");
					oos.writeObject(map);
					oos.flush();

					break;
				case 3:
					objectArr = (Object[]) returnMap.get("DATA");
					revdto = (ReviewDTO) objectArr[0];
					Boolean result = revdao.insertReview(revdto);
					revdao.calAveragerating(revdto.getRes_id());

					if (revdto.getRating() > 5) {
						fdao.updateWeatherCnt(((FoodDTO) objectArr[1]).getName(), (WeatherDTO) objectArr[2]);
					}

					map.put("TYPE", "RESTAURANT_RES");
					map.put("CODE", 3);
					map.put("DATA", result);

					System.out.println("리뷰 등록 결과 전송");
					oos.writeObject(map);
					oos.flush();

					break;
				}
				break;
			case "RECOMMEND_FOOD":
				switch (code) {
				case 1:
					objectArr = (Object[]) returnMap.get("DATA");

					fdto = (FoodDTO) objectArr[0];
					wdto = (WeatherDTO) objectArr[1];

					boolean result;
					if (fdao.insertFood(fdto)) {
						result = true;
					} else {
						result = false;
					}
					fdao.updateWeatherCnt(fdto.getName(), wdto);

					map.put("TYPE", "RECOMMEND_FOOD_RES");
					map.put("CODE", 1);
					map.put("DATA", result);

					System.out.println("음식 추천 결과 정보 전송");
					oos.writeObject(map);
					oos.flush();
					break;
				}
				break;
			case "FIND":
				switch (code) {
				case 1:
					mdto = (MemberDTO) returnMap.get("DATA");
					String outputMemId = mdao.selectMemberID(mdto.getPhone_num());
					map.put("TYPE", "FIND_ID_RES");
					map.put("CODE", 1);
					map.put("DATA", outputMemId);

					System.out.println("아이디 정보 전송");
					oos.writeObject(map);
					oos.flush();

					break;
				case 2:
					mdto = (MemberDTO) returnMap.get("DATA");
					boolean outputMem = mdao.selectMemberPassword(mdto.getMem_Id(), mdto.getPhone_num());
					if (outputMem) {
						map.put("TYPE", "FIND_PWD_RES");
						map.put("CODE", 1);

						System.out.println("비밀번호 존재 정보 전송");
						oos.writeObject(map);
						oos.flush();
					} else {
						map.put("TYPE", "FIND_PWD_RES");
						map.put("CODE", 2);

						System.out.println("비밀번호 존재X 정보 전송");
						oos.writeObject(map);
						oos.flush();
					}
					break;
				}
				break;
			case "CHANGE":
				switch (code) {
				case 1:
					mdto = (MemberDTO) returnMap.get("DATA");
					Boolean updateMemPwdResult = mdao.updateMemPWD(mdto.getMem_Id(), mdto.getPassword());
					if (updateMemPwdResult) {
						map.put("TYPE", "CHANGE_RES");
						map.put("CODE", 1);

						System.out.println("비번 변경 성공 정보 전송");
						oos.writeObject(map);
						oos.flush();
					} else {
						map.put("TYPE", "CHANGE_RES");
						map.put("CODE", 2);

						System.out.println("비번 변경 실패 정보 전송");
						oos.writeObject(map);
						oos.flush();
					}
					break;
				}
				break;
			case "CHANGE_INFO":
				switch (code) {
				case 1:
					String inputMemId = (String) returnMap.get("DATA");
					mdto = mdao.displayMyInfo(inputMemId);
					map.put("TYPE", "DISPLAY_INFO_RES");
					map.put("CODE", 1);
					map.put("DATA", mdto);
					System.out.println("정보 전송");
					oos.writeObject(map);
					oos.flush();
					break;
				case 2:
					mdto = (MemberDTO) returnMap.get("DATA");

					if (mdao.updateMemInfo(mdto)) {
						map.put("TYPE", "CHANGE_INFO_RES");
						map.put("CODE", 1);
						System.out.println("정보 수정 성공 정보 전송");
						oos.writeObject(map);
						oos.flush();
					} else {
						map.put("TYPE", "CHANGE_INFO_RES");
						map.put("CODE", 2);
						System.out.println("정보 수정 실패 정보 전송");
						oos.writeObject(map);
						oos.flush();
					}

				}
				break;
			}
			// end switch
			if (program_stop) {
				break;
			}
		}

	}

	public void closeAll() throws IOException {
		if (socket != null)
			socket.close();
	}
}
