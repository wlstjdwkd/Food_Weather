package DAO;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import commonSetting.ConnectSetting;

import java.sql.PreparedStatement;

public class RegionDAO {

	boolean insertResult = false;
	boolean deleteResult = false;
	boolean updateresult = false;
	PreparedStatement pstmt = null;
	Connection conn = null;
	String result = "";

	String[] addressResult = new String[2];
	private ResultSet rs = null;

	public String[] addressXY(String firstAddress, String secondAddress, String thirdAddress) { // 내 정보 조회 요청
		String SQL = "SELECT X, Y FROM REGION WHERE FIRSTNAME = \'" + firstAddress + "\' AND SECONDNAME = \'"
				+ secondAddress + "\' AND THIRDNAME = \'" + thirdAddress + "\'";
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				result = result + rs.getString("X") + " ";
				result = result + rs.getString("Y");

				addressResult = result.split(" ");
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return addressResult;
	}
}
