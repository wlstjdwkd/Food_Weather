package DAO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import DTO.ReviewDTO;
import commonSetting.ConnectSetting;

import java.sql.PreparedStatement;

public class ReviewDAO {

	private boolean insertResult = false;
	private boolean updateResult = false;
	private boolean deleteResult = false;
	private PreparedStatement pstmt = null; //
	private CallableStatement cstmt = null;
	private Connection conn = null;
	private ResultSet rs = null;
	String result = "";

	public boolean insertReview(ReviewDTO dto) { // 리뷰 추가
		String SQL = "INSERT INTO REVIEW(RATING,CONTENT,RES_ID,MEM_ID,REG_DATE)" + "VALUES (?,?,?,?,?)";
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setDouble(1, dto.getRating());
			pstmt.setString(2, dto.getContent());
			pstmt.setString(3, dto.getRes_id());
			pstmt.setString(4, dto.getMem_id());
			pstmt.setString(5, dto.getReg_date());
			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("INSERT문에서 예외 발생");
			sqle.printStackTrace();
			insertResult = false;
			return insertResult;
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		insertResult = true;
		return insertResult;
	}

	public boolean updateReview(ReviewDTO dto) {
		// 수정)
		String SQL = "UPDATE REVIEW SET RATING = ? , CONTENT = ? , RES_ID = ? WHERE REV_ID= ? AND MEM_ID=?";

		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setDouble(1, dto.getRating());
			pstmt.setString(2, dto.getContent());
			pstmt.setString(3, dto.getRes_id());
			pstmt.setString(4, dto.getRev_id());
			pstmt.setString(5, dto.getMem_id());
			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("UPDATE문에서 예외 발생");
			sqle.printStackTrace();
			updateResult = false;
			return updateResult;
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		updateResult = true;
		return updateResult;
	}

	public ReviewDTO[] displayReview(String resId) {
		int rowNum = displayReviewNum(resId);
		String SQL = "SELECT * FROM REVIEW WHERE RES_ID = \'" + resId + "\'";
		ReviewDTO[] dto = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			dto = new ReviewDTO[rowNum];
			int i = 0;
			while (rs.next()) {
				dto[i] = new ReviewDTO();
				dto[i].setRating(rs.getInt("RATING"));
				dto[i].setContent(rs.getString("CONTENT"));
				dto[i].setRes_id(rs.getString("RES_ID"));
				dto[i].setRev_id(rs.getString("REV_ID"));
				dto[i].setMem_id(rs.getString("MEM_ID"));
				dto[i].setReg_date(rs.getString("REG_DATE"));
				i++;
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return dto;
	}

	public int displayReviewNum(String resId) {
		String SQL = "SELECT COUNT(*) FROM REVIEW WHERE RES_ID= \'" + resId + "\'";
		int resultint = 0;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				resultint = rs.getInt("COUNT(*)");// ?
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return resultint;
	}

	public boolean deleteReview(String revid) {
		String SQL = "DELETE FROM REVIEW WHERE REV_ID = ?";

		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, revid);

			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("DELETE문에서 예외 발생");
			sqle.printStackTrace();
			deleteResult = false;
			return deleteResult;
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		deleteResult = true;
		return deleteResult;
	}

	public boolean calAveragerating(String resid) {
		String SQL = "{call RATE_CAL(?)}";
		try {
			conn = ConnectSetting.getConnection();
			cstmt = conn.prepareCall(SQL);
			cstmt.setString(1, resid);
			cstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("프로시저문에서 예외 발생");
			sqle.printStackTrace();
			return false;
		} finally {
			if (cstmt != null)
				try {
					cstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return true;
	}

}
