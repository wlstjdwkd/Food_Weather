package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import DTO.FoodDTO;
import DTO.WeatherDTO;
import commonSetting.ConnectSetting;

import java.sql.PreparedStatement;

public class FoodDAO {
	boolean insertResult = false;
	boolean deleteResult = false;
	boolean updateResult = false;

	private PreparedStatement pstmt = null;
	private Connection conn = null;
	private ResultSet rs = null;
	private Boolean updateresult = true;

	public boolean insertFood(FoodDTO dto) {

		String SQL = "INSERT INTO FOOD(NAME,FOOD_CATEGORY,WEATHER_GOOD_CNT,WEATHER_RAIN_CNT,WEATHER_SNOW_CNT,FINEDUST_BAD_CNT)VALUES(?,?,0,0,0,0)";
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, dto.getName());
			pstmt.setString(2, dto.getFood_category());
			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("INSERT문에서 예외 발생");
			sqle.printStackTrace();
			insertResult = false;
			return insertResult;
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		insertResult = true;
		return insertResult;
	}

	public FoodDTO[] displayGoodWeatherFood() {
		int cnt = displayFoodNum();
		System.out.println(cnt);
		String SQL = "SELECT NAME,FOOD_CATEGORY FROM FOOD WHERE FOOD_CATEGORY='식사' ORDER BY WEATHER_GOOD_CNT DESC,DBMS_RANDOM.VALUE";
		FoodDTO[] dto = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			dto = new FoodDTO[cnt];
			int i = 0;
			while (rs.next()) {
				dto[i] = new FoodDTO();
				dto[i].setName(rs.getString("NAME"));
				dto[i].setFood_category(rs.getString("FOOD_CATEGORY"));
				i++;
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT臾몄뿉�꽌 �삁�쇅 諛쒖깮");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return dto;
	}

	public FoodDTO[] displayGoodWeatherDessert() {
		int cnt = displayDessertNum();
		System.out.println(cnt);
		String SQL = "SELECT NAME,FOOD_CATEGORY FROM FOOD WHERE FOOD_CATEGORY='디저트' ORDER BY WEATHER_GOOD_CNT DESC,DBMS_RANDOM.VALUE";
		FoodDTO[] dto = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			dto = new FoodDTO[cnt];
			int i = 0;
			while (rs.next()) {
				dto[i] = new FoodDTO();
				dto[i].setName(rs.getString("NAME"));
				dto[i].setFood_category(rs.getString("FOOD_CATEGORY"));
				i++;
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT臾몄뿉�꽌 �삁�쇅 諛쒖깮");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return dto;
	}

	public FoodDTO[] displayRainFood() {
		int cnt = displayFoodNum();
		String SQL = "SELECT NAME,FOOD_CATEGORY FROM FOOD WHERE FOOD_CATEGORY='식사' ORDER BY WEATHER_RAIN_CNT DESC,DBMS_RANDOM.VALUE";
		FoodDTO[] dto = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			dto = new FoodDTO[cnt];
			int i = 0;
			while (rs.next()) {
				dto[i] = new FoodDTO();
				dto[i].setName(rs.getString("NAME"));
				dto[i].setFood_category(rs.getString("FOOD_CATEGORY"));
				i++;
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT臾몄뿉�꽌 �삁�쇅 諛쒖깮");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return dto;
	}

	public FoodDTO[] displayRainDessert() {
		int cnt = displayDessertNum();
		String SQL = "SELECT NAME,FOOD_CATEGORY FROM FOOD WHERE FOOD_CATEGORY='디저트' ORDER BY WEATHER_RAIN_CNT DESC,DBMS_RANDOM.VALUE";
		FoodDTO[] dto = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			dto = new FoodDTO[cnt];
			int i = 0;
			while (rs.next()) {
				dto[i] = new FoodDTO();
				dto[i].setName(rs.getString("NAME"));
				dto[i].setFood_category(rs.getString("FOOD_CATEGORY"));
				i++;
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT臾몄뿉�꽌 �삁�쇅 諛쒖깮");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return dto;
	}

	public FoodDTO[] displaySnowFood() {
		int cnt = displayFoodNum();
		String SQL = "SELECT NAME,FOOD_CATEGORY FROM FOOD WHERE FOOD_CATEGORY='식사' ORDER BY WEATHER_SNOW_CNT DESC,DBMS_RANDOM.VALUE";
		FoodDTO[] dto = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			dto = new FoodDTO[cnt];
			int i = 0;
			while (rs.next()) {
				dto[i] = new FoodDTO();
				dto[i].setName(rs.getString("NAME"));
				dto[i].setFood_category(rs.getString("FOOD_CATEGORY"));
				i++;
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT臾몄뿉�꽌 �삁�쇅 諛쒖깮");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return dto;
	}

	public FoodDTO[] displaySnowDessert() {
		int cnt = displayDessertNum();
		String SQL = "SELECT NAME,FOOD_CATEGORY FROM FOOD WHERE FOOD_CATEGORY='디저트' ORDER BY WEATHER_SNOW_CNT DESC,DBMS_RANDOM.VALUE";
		FoodDTO[] dto = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			dto = new FoodDTO[cnt];
			int i = 0;
			while (rs.next()) {
				dto[i] = new FoodDTO();
				dto[i].setName(rs.getString("NAME"));
				dto[i].setFood_category(rs.getString("FOOD_CATEGORY"));
				i++;
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT臾몄뿉�꽌 �삁�쇅 諛쒖깮");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return dto;
	}

	public FoodDTO[] displayBadFinedustFood() {
		int cnt = displayFoodNum();
		String SQL = "SELECT NAME,FOOD_CATEGORY FROM FOOD WHERE FOOD_CATEGORY='식사' ORDER BY FINEDUST_BAD_CNT DESC,DBMS_RANDOM.VALUE";
		FoodDTO[] dto = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			dto = new FoodDTO[cnt];
			int i = 0;
			while (rs.next()) {
				dto[i] = new FoodDTO();
				dto[i].setName(rs.getString("NAME"));
				dto[i].setFood_category(rs.getString("FOOD_CATEGORY"));
				i++;
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT臾몄뿉�꽌 �삁�쇅 諛쒖깮");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return dto;
	}

	public FoodDTO[] displayBadFinedustDessert() {
		int cnt = displayDessertNum();
		String SQL = "SELECT NAME,FOOD_CATEGORY FROM FOOD WHERE FOOD_CATEGORY='디저트' ORDER BY FINEDUST_BAD_CNT DESC,DBMS_RANDOM.VALUE";
		FoodDTO[] dto = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			dto = new FoodDTO[cnt];
			int i = 0;
			while (rs.next()) {
				dto[i] = new FoodDTO();
				dto[i].setName(rs.getString("NAME"));
				dto[i].setFood_category(rs.getString("FOOD_CATEGORY"));
				i++;
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT臾몄뿉�꽌 �삁�쇅 諛쒖깮");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return dto;
	}

	public int displayFoodNum() {
		String SQL = "SELECT COUNT(*) FROM FOOD WHERE FOOD_CATEGORY='식사'";
		int resultint = 0;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				resultint = rs.getInt("COUNT(*)"); // ?
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return resultint;
	}

	public int displayDessertNum() {
		String SQL = "SELECT COUNT(*) FROM FOOD WHERE FOOD_CATEGORY='디저트'";
		int resultint = 0;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				resultint = rs.getInt("COUNT(*)"); // ?
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return resultint;
	}

	public boolean updateWeatherCnt(String foodName, WeatherDTO weather) {
		String weatherSQL = null;

		switch (weather.getSky() % 10) {
		case 0:
			switch (weather.getSky() / 10) {
			case 1: // 맑음
			case 2:
			case 3: // 구름많음
			case 4: // 흐림
				weatherSQL = "WEATHER_GOOD_CNT";
				break;
			}
			if ((weather.getFineDust() > 80) || (weather.getUltraFineDust() > 35)) {
				weatherSQL = "FINEDUST_BAD_CNT";
			}
			break;
		case 1:
		case 4:
		case 5: // 비
			weatherSQL = "WEATHER_RAIN_CNT";
			break;
		case 2:
		case 3:
		case 6:
		case 7: // 눈
			weatherSQL = "WEATHER_SNOW_CNT";
			break;
		}

		String SQL = "UPDATE FOOD SET " + weatherSQL + "=" + weatherSQL + "+1 WHERE NAME=?";

		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, foodName);
			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("UPDATE문에서 예외 발생");
			sqle.printStackTrace();
			updateresult = false;
			return updateresult;
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		updateresult = true;
		return updateresult;
	}
}