package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import DTO.RestaurantDTO;

import commonSetting.ConnectSetting;

import java.sql.PreparedStatement;

public class RestaurantDAO {
	boolean insertResult = false;
	boolean deleteResult = false;
	boolean updateresult = false;
	boolean deleteresult = false;
	PreparedStatement pstmt = null;
	Connection conn = null;
	String result = "";
	private ResultSet rs = null;

	public boolean insertRestaurant(RestaurantDTO dto) { // 식당 추가

		String SQL = "INSERT INTO RESTAURANT(NAME,CATEGORY,AVERAGERATING,ADDRESS)" + "VALUES (?,?,?,?)";
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, dto.getName());
			pstmt.setString(2, dto.getCategory());
			pstmt.setDouble(3, dto.getAveragerating());
			pstmt.setString(4, dto.getAddress());

			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("INSERT문에서 예외 발생");
			sqle.printStackTrace();
			insertResult = false;
			return insertResult;
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		insertResult = true;
		return insertResult;
	}

	public boolean restaurantCheck(String inputName, String inputAddress) { // 식당중복체크 (식당이 중복되면 추가X)
		PreparedStatement custmt = null;
		ResultSet rsCusto = null;
		boolean result = false;

		String SQL = "SELECT * FROM RESTAURANT WHERE NAME = ? AND ADDRESS=?";

		try {
			conn = ConnectSetting.getConnection();
			custmt = conn.prepareStatement(SQL);
			custmt.setString(1, inputName);
			custmt.setString(2, inputAddress);
			rsCusto = custmt.executeQuery();

			if (rsCusto.next()) {
				result = true;
			}

		} catch (SQLException sqle) {
			System.out.println("SQL문에서 예외 발생");
			sqle.printStackTrace();
		} finally {

			if (rsCusto != null)
				try {
					rsCusto.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (custmt != null)
				try {
					custmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return result;
	}

	public boolean updateRestaurant(RestaurantDTO dto) {
		String SQL = "UPDATE RESTAURANT SET NAME= ? , CATEGORY = ? , AVERAGERATING= ? MENU=? ADDRESS=? WHERE RES_ID= ?";

		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, dto.getName());
			pstmt.setString(2, dto.getCategory());
			pstmt.setDouble(3, dto.getAveragerating());
			pstmt.setString(4, dto.getAddress());
			pstmt.setString(5, dto.getRes_id());
			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("UPDATE문에서 예외 발생");
			sqle.printStackTrace();
			updateresult = false;
			return updateresult;
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		updateresult = true;
		return updateresult;
	}

	public RestaurantDTO displayRestaurant(String inputName, String inputAddress) {
		String SQL = "SELECT * FROM RESTAURANT WHERE NAME=? AND ADDRESS=?";
		RestaurantDTO dto = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, inputName);
			pstmt.setString(2, inputAddress);
			rs = pstmt.executeQuery();
			dto = new RestaurantDTO();
			if (rs.next()) {
				dto.setRes_id(rs.getString("RES_ID"));
				dto.setName(rs.getString("NAME"));
				dto.setCategory(rs.getString("CATEGORY"));
				dto.setAveragerating(rs.getDouble("AVERAGERATING"));
				dto.setAddress(rs.getString("ADDRESS"));
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return dto;
	}

	public int displayRestaurantNum() {
		String SQL = "SELECT COUNT(*) FROM RESTAURANT";
		int resultint = 0;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();

			resultint = rs.getInt("COUNT(*)");// ?

		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return resultint;
	}

	public Double displayAverRate(String inputResId) {
		String SQL = "SELECT AVERAGERATING FROM RESTAURANT WHERE RES_ID=?";
		Double result = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, inputResId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				result = rs.getDouble("AVERAGERATING");
				System.out.println("식당 평점 : " + result);
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return result;
	}

}
