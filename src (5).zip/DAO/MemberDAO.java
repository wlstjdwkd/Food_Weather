package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import DTO.MemberDTO;
import commonSetting.ConnectSetting;

import java.sql.PreparedStatement;

public class MemberDAO {

	boolean insertResult = false;
	boolean deleteResult = false;
	boolean updateresult = false;
	String[] addressResult = new String[3];
	PreparedStatement pstmt = null;
	Connection conn = null;
	String result = "";
	private ResultSet rs = null;

	public boolean insertCustomer(MemberDTO dto) { // 고객 추가(회원가입)

		String SQL = "INSERT INTO MEMBER(MEM_ID,PASSWORD,NAME,AGE,GENDER,PHONE_NUM,ADDRESS,DISLIKEFOOD)"
				+ "VALUES (?,?,?,?,?,?,?,?)";
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, dto.getMem_Id());
			pstmt.setInt(2, dto.getPassword());
			pstmt.setString(3, dto.getName());
			pstmt.setInt(4, dto.getAge());
			pstmt.setString(5, dto.getGender());
			pstmt.setString(6, dto.getPhone_num());
			pstmt.setString(7, dto.getAddress());
			pstmt.setString(8, dto.getDislikeFood());

			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("INSERT문에서 예외 발생");
			sqle.printStackTrace();
			insertResult = false;
			return insertResult;
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		insertResult = true;
		return insertResult;
	}

	public boolean loginRequest(MemberDTO input) { // 로그인 요청
		PreparedStatement custmt = null;
		ResultSet rsCusto = null;
		boolean loginResult = false;
		String SQLcu = "SELECT PASSWORD FROM MEMBER WHERE MEM_ID = \'" + input.getMem_Id() + "\'";
		try {
			conn = ConnectSetting.getConnection();
			custmt = conn.prepareStatement(SQLcu);
			rsCusto = custmt.executeQuery();
			if (rsCusto.next()) {
				int dbPw = Integer.parseInt(rsCusto.getString(1));

				if (dbPw == input.getPassword()) {
					loginResult = true; // 안되면 getString 1
				}
			}

		} catch (SQLException sqle) {
			System.out.println("SQL문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rsCusto != null)
				try {
					rsCusto.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (custmt != null)
				try {
					custmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return loginResult;
	}

	public String selectMemberID(String phone_num) { // 아이디 찾기 요청
		PreparedStatement custmt = null;
		ResultSet rsCusto = null;
		String loginResult = "false";

		String SQLcu = "SELECT MEM_ID FROM MEMBER WHERE PHONE_NUM = \'" + phone_num + "\'";
		try {
			conn = ConnectSetting.getConnection();
			custmt = conn.prepareStatement(SQLcu);
			rsCusto = custmt.executeQuery();

			if (rsCusto.next()) {
				loginResult = rsCusto.getString("MEM_ID"); // 안되면 getString 1
			}

		} catch (SQLException sqle) {
			System.out.println("SQL문에서 예외 발생");
			sqle.printStackTrace();
		} finally {

			if (rsCusto != null)
				try {
					rsCusto.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (custmt != null)
				try {
					custmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return loginResult;
	}

	public boolean selectMemberPassword(String id, String phone_num) { // 비밀번호
		PreparedStatement custmt = null;
		ResultSet rsCusto = null;
		boolean loginResult = false;

		String SQLcu = "SELECT * FROM MEMBER WHERE MEM_ID = \'" + id + "\' AND PHONE_NUM = \'" + phone_num + "\'";
		try {
			conn = ConnectSetting.getConnection();
			custmt = conn.prepareStatement(SQLcu);
			rsCusto = custmt.executeQuery();

			if (rsCusto.next()) {
				loginResult = true; // 안되면 getString 1
			}

		} catch (SQLException sqle) {
			System.out.println("SQL문에서 예외 발생");
			sqle.printStackTrace();
		} finally {

			if (rsCusto != null)
				try {
					rsCusto.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (custmt != null)
				try {
					custmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return loginResult;
	}

	public boolean updateMemPWD(String id, int password) { // 비밀번호 재설정 요청
		String SQL = "UPDATE MEMBER SET PASSWORD = \'" + password + "\'  WHERE MEM_ID = \'" + id + "\'";

		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("UPDATE문에서 예외 발생");
			sqle.printStackTrace();
			updateresult = false;
			return updateresult;
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		updateresult = true;
		return updateresult;
	}

	public boolean updateMemInfo(MemberDTO inputdto) { // 회원정보
																											// 수정(내정보
																											// 수정)
		String SQL = "UPDATE MEMBER SET DISLIKEFOOD=?,GENDER=?,NAME=?,ADDRESS=?,PHONE_NUM=?,AGE=? WHERE MEM_ID=?";

		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, inputdto.getDislikeFood());
			pstmt.setString(2, inputdto.getGender());
			pstmt.setString(3, inputdto.getName());
			pstmt.setString(4, inputdto.getAddress());
			pstmt.setString(5, inputdto.getPhone_num());
			pstmt.setInt(6, inputdto.getAge());
			pstmt.setString(7, inputdto.getMem_Id());

			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("UPDATE문에서 예외 발생");
			sqle.printStackTrace();
			updateresult = false;
			return updateresult;
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		updateresult = true;
		return updateresult;
	}

	public boolean idCheck(String id) { // id중복
		PreparedStatement custmt = null;
		ResultSet rsCusto = null;
		boolean loginResult = false;

		String SQL = "SELECT * FROM MEMBER WHERE MEM_ID = \'" + id + "\'";

		try {
			conn = ConnectSetting.getConnection();
			custmt = conn.prepareStatement(SQL);
			rsCusto = custmt.executeQuery();

			if (rsCusto.next()) {
				loginResult = true;
			}

		} catch (SQLException sqle) {
			System.out.println("SQL문에서 예외 발생");
			sqle.printStackTrace();
		} finally {

			if (rsCusto != null)
				try {
					rsCusto.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (custmt != null)
				try {
					custmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return loginResult;

	}

	public boolean deleteCustomer(String id) { // 회원 탈퇴
		String SQL = "DELETE FROM MEMBER WHERE MEM_ID = ?";

		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, id);

			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("DELETE문에서 예외 발생");
			sqle.printStackTrace();
			deleteResult = false;
			return deleteResult;
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		deleteResult = true;
		return deleteResult;
	}

	public MemberDTO displayMyInfo(String inputMemId) { // 내 정보 조회 요청
		MemberDTO memdto=new MemberDTO();
		String SQL = "SELECT * FROM MEMBER WHERE MEM_ID=?";

		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, inputMemId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				memdto.setMem_Id(rs.getString("MEM_ID"));
				memdto.setName(rs.getString("NAME"));
				memdto.setPassword(rs.getInt("PASSWORD"));
				memdto.setDislikeFood(rs.getString("DISLIKEFOOD"));
				memdto.setGender(rs.getString("GENDER"));
				memdto.setAddress(rs.getString("ADDRESS"));
				memdto.setPhone_num(rs.getString("PHONE_NUM"));
				memdto.setAge(rs.getInt("AGE"));
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return memdto;
	}

	public String[] addressInfo(String inputMemId) { // 내 정보 조회 요청
		String SQL = "SELECT ADDRESS FROM MEMBER WHERE MEM_ID=?";

		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, inputMemId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				result = rs.getString("ADDRESS");
				addressResult = result.split(" ");
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		return addressResult;
	}

	public String[] displayDislikefood(String memId) {
		String SQL = "SELECT DISLIKEFOOD FROM MEMBER WHERE MEM_ID = \'" + memId + "\'";
		String[] dislikeList = null;
		String dislike = null;
		try {
			conn = ConnectSetting.getConnection();
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				dislike = rs.getString("DISLIKEFOOD");
			}
		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
		}
		dislikeList = dislike.split(",");
		return dislikeList;
	}
}